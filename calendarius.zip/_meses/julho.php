<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("z1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz1",$maccabeus1);
  }
}
$z1d=isset($_COOKIE["z1"])?$_COOKIE["z1"]:1;
$zz1d=isset($_COOKIE["zz1"])?$_COOKIE["zz1"]:"";
$zzz1d=isset($_COOKIE["zzz1"])?$_COOKIE["zzz1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("z2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz2",$maccabeus1);
  }
}
$z2d=isset($_COOKIE["z2"])?$_COOKIE["z2"]:2;
$zz2d=isset($_COOKIE["zz2"])?$_COOKIE["zz2"]:"";
$zzz2d=isset($_COOKIE["zzz2"])?$_COOKIE["zzz2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("z3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz3",$maccabeus1);
    $zz1d=isset($_COOKIE["zz3"])?$_COOKIE["zz3"]:"";
  }
  if($taf=="3"){
    setcookie("zzz3",$maccabeus1);
  }
}
$z3d=isset($_COOKIE["z3"])?$_COOKIE["z3"]:3;
$zz3d=isset($_COOKIE["zz3"])?$_COOKIE["zz3"]:"";
$zzz3d=isset($_COOKIE["zzz3"])?$_COOKIE["zzz3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("z4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz4",$maccabeus1);
  }
}
$z4d=isset($_COOKIE["z4"])?$_COOKIE["z4"]:4;
$zz4d=isset($_COOKIE["zz4"])?$_COOKIE["zz4"]:"";
$zzz4d=isset($_COOKIE["zzz4"])?$_COOKIE["zzz4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("z5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz5",$maccabeus1);
  }
}
$z5d=isset($_COOKIE["z5"])?$_COOKIE["z5"]:5;
$zz5d=isset($_COOKIE["zz5"])?$_COOKIE["zz5"]:"";
$zzz5d=isset($_COOKIE["zzz5"])?$_COOKIE["zzz5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("z6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz6",$maccabeus1);
  }
}
$z6d=isset($_COOKIE["z6"])?$_COOKIE["z6"]:6;
$zz6d=isset($_COOKIE["zz6"])?$_COOKIE["zz6"]:"";
$zzz6d=isset($_COOKIE["zzz6"])?$_COOKIE["zzz6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("z7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz7",$maccabeus1);
  }
}
$z7d=isset($_COOKIE["z7"])?$_COOKIE["z7"]:7;
$zz7d=isset($_COOKIE["zz7"])?$_COOKIE["zz7"]:"";
$zzz7d=isset($_COOKIE["zzz7"])?$_COOKIE["zzz7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("z8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz8",$maccabeus1);
  }
}
$z8d=isset($_COOKIE["z8"])?$_COOKIE["z8"]:8;
$zz8d=isset($_COOKIE["zz8"])?$_COOKIE["zz8"]:"";
$zzz8d=isset($_COOKIE["zzz8"])?$_COOKIE["zzz8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("z9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz9",$maccabeus1);
  }
}
$z9d=isset($_COOKIE["z9"])?$_COOKIE["z9"]:9;
$zz9d=isset($_COOKIE["zz9"])?$_COOKIE["zz9"]:"";
$zzz9d=isset($_COOKIE["zzz9"])?$_COOKIE["zzz9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("z10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz10",$maccabeus1);
  }
}
$z10d=isset($_COOKIE["z10"])?$_COOKIE["z10"]:10;
$zz10d=isset($_COOKIE["zz10"])?$_COOKIE["zz10"]:"";
$zzz10d=isset($_COOKIE["zzz10"])?$_COOKIE["zzz10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("z11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz11",$maccabeus1);
  }
}
$z11d=isset($_COOKIE["z11"])?$_COOKIE["z11"]:11;
$zz11d=isset($_COOKIE["zz11"])?$_COOKIE["zz11"]:"";
$zzz11d=isset($_COOKIE["zzz11"])?$_COOKIE["zzz11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("z12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz12",$maccabeus1);
  }
}
$z12d=isset($_COOKIE["z12"])?$_COOKIE["z12"]:12;
$zz12d=isset($_COOKIE["zz12"])?$_COOKIE["zz12"]:"";
$zzz12d=isset($_COOKIE["zzz12"])?$_COOKIE["zzz12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("z13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz13",$maccabeus1);
  }
}
$z13d=isset($_COOKIE["z13"])?$_COOKIE["z13"]:13;
$zz13d=isset($_COOKIE["zz13"])?$_COOKIE["zz13"]:"";
$zzz13d=isset($_COOKIE["zzz13"])?$_COOKIE["zzz13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("z14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz14",$maccabeus1);
  }
}
$z14d=isset($_COOKIE["z14"])?$_COOKIE["z14"]:14;
$zz14d=isset($_COOKIE["zz14"])?$_COOKIE["zz14"]:"";
$zzz14d=isset($_COOKIE["zzz14"])?$_COOKIE["zzz14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("z15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz15",$maccabeus1);
  }
}
$z15d=isset($_COOKIE["z15"])?$_COOKIE["z1"]:15;
$zz15d=isset($_COOKIE["zz15"])?$_COOKIE["zz15"]:"";
$zzz15d=isset($_COOKIE["zzz15"])?$_COOKIE["zzz15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("z16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz16",$maccabeus1);
  }
}
$z16d=isset($_COOKIE["z16"])?$_COOKIE["z16"]:16;
$zz16d=isset($_COOKIE["zz16"])?$_COOKIE["zz16"]:"";
$zzz16d=isset($_COOKIE["zzz16"])?$_COOKIE["zzz16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("z17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz17",$maccabeus1);
  }
}
$z17d=isset($_COOKIE["z17"])?$_COOKIE["z17"]:17;
$zz17d=isset($_COOKIE["zz17"])?$_COOKIE["zz17"]:"";
$zzz17d=isset($_COOKIE["zzz17"])?$_COOKIE["zzz17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("z18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz18",$maccabeus1);
  }
}
$z18d=isset($_COOKIE["z18"])?$_COOKIE["z18"]:18;
$zz18d=isset($_COOKIE["zz18"])?$_COOKIE["zz18"]:"";
$zzz18d=isset($_COOKIE["zzz18"])?$_COOKIE["zzz18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("z19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz19",$maccabeus1);
  }
}
$z19d=isset($_COOKIE["z19"])?$_COOKIE["z19"]:19;
$zz19d=isset($_COOKIE["zz19"])?$_COOKIE["zz19"]:"";
$zzz19d=isset($_COOKIE["zzz19"])?$_COOKIE["zzz19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("z2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz2",$maccabeus1);
  }
}
$z20d=isset($_COOKIE["z2"])?$_COOKIE["z2"]:20;
$zz20d=isset($_COOKIE["zz2"])?$_COOKIE["zz2"]:"";
$zzz20d=isset($_COOKIE["zzz2"])?$_COOKIE["zzz2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("z21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz21",$maccabeus1);
  }
}
$z21d=isset($_COOKIE["z21"])?$_COOKIE["z21"]:21;
$zz21d=isset($_COOKIE["zz21"])?$_COOKIE["zz21"]:"";
$zzz21d=isset($_COOKIE["zzz21"])?$_COOKIE["zzz21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("z22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz22",$maccabeus1);
  }
}
$z22d=isset($_COOKIE["z22"])?$_COOKIE["z22"]:22;
$zz22d=isset($_COOKIE["zz22"])?$_COOKIE["zz22"]:"";
$zzz22d=isset($_COOKIE["zzz22"])?$_COOKIE["zzz22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("z23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz23",$maccabeus1);
  }
}
$z23d=isset($_COOKIE["z23"])?$_COOKIE["z23"]:23;
$zz23d=isset($_COOKIE["zz23"])?$_COOKIE["zz23"]:"";
$zzz23d=isset($_COOKIE["zzz23"])?$_COOKIE["zzz23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("z24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz24",$maccabeus1);
  }
}
$z24d=isset($_COOKIE["z24"])?$_COOKIE["z24"]:24;
$zz24d=isset($_COOKIE["zz24"])?$_COOKIE["zz24"]:"";
$zzz24d=isset($_COOKIE["zzz24"])?$_COOKIE["zzz24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("z25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz25",$maccabeus1);
  }
}
$z25d=isset($_COOKIE["z25"])?$_COOKIE["z25"]:25;
$zz25d=isset($_COOKIE["zz25"])?$_COOKIE["zz25"]:"";
$zzz25d=isset($_COOKIE["zzz25"])?$_COOKIE["zzz25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("z26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz26",$maccabeus1);
  }
}
$z26d=isset($_COOKIE["z26"])?$_COOKIE["z26"]:26;
$zz26d=isset($_COOKIE["zz26"])?$_COOKIE["zz26"]:"";
$zzz26d=isset($_COOKIE["zzz26"])?$_COOKIE["zzz26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("z27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz27",$maccabeus1);
  }
}
$z27d=isset($_COOKIE["z27"])?$_COOKIE["z27"]:27;
$zz27d=isset($_COOKIE["zz27"])?$_COOKIE["zz27"]:"";
$zzz27d=isset($_COOKIE["zzz27"])?$_COOKIE["zzz27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("z28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz28",$maccabeus1);
  }
}
$z28d=isset($_COOKIE["z28"])?$_COOKIE["z28"]:28;
$zz28d=isset($_COOKIE["zz28"])?$_COOKIE["zz28"]:"";
$zzz28d=isset($_COOKIE["zzz28"])?$_COOKIE["zzz28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("z29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz29",$maccabeus1);
  }
}
$z29d=isset($_COOKIE["z29"])?$_COOKIE["z29"]:29;
$zz29d=isset($_COOKIE["zz29"])?$_COOKIE["zz29"]:"";
$zzz29d=isset($_COOKIE["zzz29"])?$_COOKIE["zzz29"]:"";
if($dia=="30"){//30
  if($taf=="1"){
    setcookie("z30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz30",$maccabeus1);
  }
}
$z30d=isset($_COOKIE["z30"])?$_COOKIE["z30"]:30;
$zz30d=isset($_COOKIE["zz30"])?$_COOKIE["zz30"]:"";
$zzz30d=isset($_COOKIE["zzz30"])?$_COOKIE["zzz30"]:"";
if($dia=="31"){//31
  if($taf=="1"){
    setcookie("z31",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zz31",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zzz31",$maccabeus1);
  }
}
$z31d=isset($_COOKIE["z31"])?$_COOKIE["z31"]:31;
$zz31d=isset($_COOKIE["zz31"])?$_COOKIE["zz31"]:"";
$zzz31d=isset($_COOKIE["zzz31"])?$_COOKIE["zzz31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Julho</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Julho</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Julho</p>
<p class="yoda">Olá, seja bem vindo ao caléndario, aqui se encontra as tarefas do més de Julho.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td id="33d" class="si"><?php echo"";?></td><td id="32d" class="se"><?php echo"";?></td><td id="33d" class="se"><?php echo"";?></td><td id="1d" class="se"><?php echo"$z1d <br> $zz1d <br> $zzz1d";?></td><td id="2d" class="se"><?php echo"$z2d <br> $zz2d <br> $zzz2d";?></td><td id="3d" class="se"><?php echo"$z3d <br> $zz3d <br> $zzz3d";?></td><td id="4d" class="so"><?php echo"$z4d <br> $zz4d <br> $zzz4d";?></td></tr>
    <tr><td id="5d" class="si"><?php echo"$z5d <br> $zz5d <br> $zzz5d";?></td><td id="6d" class="se"><?php echo"$z6d <br> $zz6d <br> $zzz6d";?></td><td id="7d" class="se"><?php echo"$z7d <br> $zz7d <br> $zzz7d";?></td><td id="8d" class="se"><?php echo"$z8d <br> $zz8d <br> $zzz8d";?></td><td id="9d" class="se"><?php echo"$z9d <br> $zz9d <br> $zzz9d";?></td><td id="10d" class="se"><?php echo"$z10d <br> $zz10d <br> $zzz10d";?></td><td id="11d" class="so"><?php echo"$z11d <br> $zz11d <br> $zzz11d";?></td></tr>
    <tr><td id="12d" class="si"><?php echo"$z12d <br> $zz12d <br> $zzz12d";?></td><td id="13d" class="se"><?php echo"$z13d <br> $zz13d <br> $zzz13d";?></td><td id="14d" class="se"><?php echo"$z14d <br> $zz14d <br> $zzz14d";?></td><td id="15d" class="se"><?php echo"$z15d <br> $zz15d <br> $zzz15d";?></td><td id="16d" class="se"><?php echo"$z16d <br> $zz16d <br> $zzz16d";?></td><td id="17d" class="se"><?php echo"$z17d <br> $zz17d <br> $zzz17d";?></td><td id="18d" class="so"><?php echo"$z18d <br> $zz18d <br> $zzz18d";?></td></tr>
    <tr><td id="19d" class="si"><?php echo"$z19d <br> $zz19d <br> $zzz19d";?></td><td id="20d" class="se"><?php echo"$z20d <br> $zz20d <br> $zzz20d";?></td><td id="21d" class="se"><?php echo"$z21d <br> $zz21d <br> $zzz21d";?></td><td id="22d" class="se"><?php echo"$z22d <br> $zz22d <br> $zzz22d";?></td><td id="23d" class="se"><?php echo"$z23d <br> $zz23d <br> $zzz23d";?></td><td id="24d" class="se"><?php echo"$z24d <br> $zz24d <br> $zzz24d";?></td><td id="25d" class="so"><?php echo"$z25d <br> $zz25d <br> $zzz25d";?></td></tr>
    <tr><td id="26d" class="si"><?php echo"$z26d <br> $zz26d <br> $zzz26d";?></td><td id="27d" class="se"><?php echo"$z27d <br> $zz27d <br> $zzz27d";?></td><td id="28d" class="se"><?php echo"$z28d <br> $zz28d <br> $zzz28d";?></td><td id="29d" class="se"><?php echo"$z29d <br> $zz29d <br> $zzz29d";?></td><td id="30d" class="se"><?php echo"$z30d <br> $zz30d <br> $zzz30d";?></td><td id="31d" class="se"><?php echo"$z31d <br> $zz31d <br> $zzz31d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="julho.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">za no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, azuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>