<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("ni1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini1",$maccabeus1);
  }
}
$ni1d=isset($_COOKIE["ni1"])?$_COOKIE["ni1"]:1;
$nini1d=isset($_COOKIE["nini1"])?$_COOKIE["nini1"]:"";
$ninini1d=isset($_COOKIE["ninini1"])?$_COOKIE["ninini1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("ni2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini2",$maccabeus1);
  }
}
$ni2d=isset($_COOKIE["ni2"])?$_COOKIE["ni2"]:2;
$nini2d=isset($_COOKIE["nini2"])?$_COOKIE["nini2"]:"";
$ninini2d=isset($_COOKIE["ninini2"])?$_COOKIE["ninini2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("ni3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini3",$maccabeus1);
    $nini1d=isset($_COOKIE["nini3"])?$_COOKIE["nini3"]:"";
  }
  if($taf=="3"){
    setcookie("ninini3",$maccabeus1);
  }
}
$ni3d=isset($_COOKIE["ni3"])?$_COOKIE["ni3"]:3;
$nini3d=isset($_COOKIE["nini3"])?$_COOKIE["nini3"]:"";
$ninini3d=isset($_COOKIE["ninini3"])?$_COOKIE["ninini3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("ni4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini4",$maccabeus1);
  }
}
$ni4d=isset($_COOKIE["ni4"])?$_COOKIE["ni4"]:4;
$nini4d=isset($_COOKIE["nini4"])?$_COOKIE["nini4"]:"";
$ninini4d=isset($_COOKIE["ninini4"])?$_COOKIE["ninini4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("ni5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini5",$maccabeus1);
  }
}
$ni5d=isset($_COOKIE["ni5"])?$_COOKIE["ni5"]:5;
$nini5d=isset($_COOKIE["nini5"])?$_COOKIE["nini5"]:"";
$ninini5d=isset($_COOKIE["ninini5"])?$_COOKIE["ninini5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("ni6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini6",$maccabeus1);
  }
}
$ni6d=isset($_COOKIE["ni6"])?$_COOKIE["ni6"]:6;
$nini6d=isset($_COOKIE["nini6"])?$_COOKIE["nini6"]:"";
$ninini6d=isset($_COOKIE["ninini6"])?$_COOKIE["ninini6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("ni7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini7",$maccabeus1);
  }
}
$ni7d=isset($_COOKIE["ni7"])?$_COOKIE["ni7"]:7;
$nini7d=isset($_COOKIE["nini7"])?$_COOKIE["nini7"]:"";
$ninini7d=isset($_COOKIE["ninini7"])?$_COOKIE["ninini7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("ni8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini8",$maccabeus1);
  }
}
$ni8d=isset($_COOKIE["ni8"])?$_COOKIE["ni8"]:8;
$nini8d=isset($_COOKIE["nini8"])?$_COOKIE["nini8"]:"";
$ninini8d=isset($_COOKIE["ninini8"])?$_COOKIE["ninini8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("ni9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini9",$maccabeus1);
  }
}
$ni9d=isset($_COOKIE["ni9"])?$_COOKIE["ni9"]:9;
$nini9d=isset($_COOKIE["nini9"])?$_COOKIE["nini9"]:"";
$ninini9d=isset($_COOKIE["ninini9"])?$_COOKIE["ninini9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("ni10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini10",$maccabeus1);
  }
}
$ni10d=isset($_COOKIE["ni10"])?$_COOKIE["ni10"]:10;
$nini10d=isset($_COOKIE["nini10"])?$_COOKIE["nini10"]:"";
$ninini10d=isset($_COOKIE["ninini10"])?$_COOKIE["ninini10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("ni11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini11",$maccabeus1);
  }
}
$ni11d=isset($_COOKIE["ni11"])?$_COOKIE["ni11"]:11;
$nini11d=isset($_COOKIE["nini11"])?$_COOKIE["nini11"]:"";
$ninini11d=isset($_COOKIE["ninini11"])?$_COOKIE["ninini11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("ni12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini12",$maccabeus1);
  }
}
$ni12d=isset($_COOKIE["ni12"])?$_COOKIE["ni12"]:12;
$nini12d=isset($_COOKIE["nini12"])?$_COOKIE["nini12"]:"";
$ninini12d=isset($_COOKIE["ninini12"])?$_COOKIE["ninini12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("ni13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini13",$maccabeus1);
  }
}
$ni13d=isset($_COOKIE["ni13"])?$_COOKIE["ni13"]:13;
$nini13d=isset($_COOKIE["nini13"])?$_COOKIE["nini13"]:"";
$ninini13d=isset($_COOKIE["ninini13"])?$_COOKIE["ninini13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("ni14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini14",$maccabeus1);
  }
}
$ni14d=isset($_COOKIE["ni14"])?$_COOKIE["ni14"]:14;
$nini14d=isset($_COOKIE["nini14"])?$_COOKIE["nini14"]:"";
$ninini14d=isset($_COOKIE["ninini14"])?$_COOKIE["ninini14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("ni15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini15",$maccabeus1);
  }
}
$ni15d=isset($_COOKIE["ni15"])?$_COOKIE["ni1"]:15;
$nini15d=isset($_COOKIE["nini15"])?$_COOKIE["nini15"]:"";
$ninini15d=isset($_COOKIE["ninini15"])?$_COOKIE["ninini15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("ni16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini16",$maccabeus1);
  }
}
$ni16d=isset($_COOKIE["ni16"])?$_COOKIE["ni16"]:16;
$nini16d=isset($_COOKIE["nini16"])?$_COOKIE["nini16"]:"";
$ninini16d=isset($_COOKIE["ninini16"])?$_COOKIE["ninini16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("ni17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini17",$maccabeus1);
  }
}
$ni17d=isset($_COOKIE["ni17"])?$_COOKIE["ni17"]:17;
$nini17d=isset($_COOKIE["nini17"])?$_COOKIE["nini17"]:"";
$ninini17d=isset($_COOKIE["ninini17"])?$_COOKIE["ninini17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("ni18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini18",$maccabeus1);
  }
}
$ni18d=isset($_COOKIE["ni18"])?$_COOKIE["ni18"]:18;
$nini18d=isset($_COOKIE["nini18"])?$_COOKIE["nini18"]:"";
$ninini18d=isset($_COOKIE["ninini18"])?$_COOKIE["ninini18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("ni19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini19",$maccabeus1);
  }
}
$ni19d=isset($_COOKIE["ni19"])?$_COOKIE["ni19"]:19;
$nini19d=isset($_COOKIE["nini19"])?$_COOKIE["nini19"]:"";
$ninini19d=isset($_COOKIE["ninini19"])?$_COOKIE["ninini19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("ni2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini2",$maccabeus1);
  }
}
$ni20d=isset($_COOKIE["ni2"])?$_COOKIE["ni2"]:20;
$nini20d=isset($_COOKIE["nini2"])?$_COOKIE["nini2"]:"";
$ninini20d=isset($_COOKIE["ninini2"])?$_COOKIE["ninini2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("ni21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini21",$maccabeus1);
  }
}
$ni21d=isset($_COOKIE["ni21"])?$_COOKIE["ni21"]:21;
$nini21d=isset($_COOKIE["nini21"])?$_COOKIE["nini21"]:"";
$ninini21d=isset($_COOKIE["ninini21"])?$_COOKIE["ninini21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("ni22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini22",$maccabeus1);
  }
}
$ni22d=isset($_COOKIE["ni22"])?$_COOKIE["ni22"]:22;
$nini22d=isset($_COOKIE["nini22"])?$_COOKIE["nini22"]:"";
$ninini22d=isset($_COOKIE["ninini22"])?$_COOKIE["ninini22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("ni23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini23",$maccabeus1);
  }
}
$ni23d=isset($_COOKIE["ni23"])?$_COOKIE["ni23"]:23;
$nini23d=isset($_COOKIE["nini23"])?$_COOKIE["nini23"]:"";
$ninini23d=isset($_COOKIE["ninini23"])?$_COOKIE["ninini23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("ni24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini24",$maccabeus1);
  }
}
$ni24d=isset($_COOKIE["ni24"])?$_COOKIE["ni24"]:24;
$nini24d=isset($_COOKIE["nini24"])?$_COOKIE["nini24"]:"";
$ninini24d=isset($_COOKIE["ninini24"])?$_COOKIE["ninini24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("ni25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini25",$maccabeus1);
  }
}
$ni25d=isset($_COOKIE["ni25"])?$_COOKIE["ni25"]:25;
$nini25d=isset($_COOKIE["nini25"])?$_COOKIE["nini25"]:"";
$ninini25d=isset($_COOKIE["ninini25"])?$_COOKIE["ninini25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("ni26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini26",$maccabeus1);
  }
}
$ni26d=isset($_COOKIE["ni26"])?$_COOKIE["ni26"]:26;
$nini26d=isset($_COOKIE["nini26"])?$_COOKIE["nini26"]:"";
$ninini26d=isset($_COOKIE["ninini26"])?$_COOKIE["ninini26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("ni27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini27",$maccabeus1);
  }
}
$ni27d=isset($_COOKIE["ni27"])?$_COOKIE["ni27"]:27;
$nini27d=isset($_COOKIE["nini27"])?$_COOKIE["nini27"]:"";
$ninini27d=isset($_COOKIE["ninini27"])?$_COOKIE["ninini27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("ni28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini28",$maccabeus1);
  }
}
$ni28d=isset($_COOKIE["ni28"])?$_COOKIE["ni28"]:28;
$nini28d=isset($_COOKIE["nini28"])?$_COOKIE["nini28"]:"";
$ninini28d=isset($_COOKIE["ninini28"])?$_COOKIE["ninini28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("ni29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini29",$maccabeus1);
  }
}
$ni29d=isset($_COOKIE["ni29"])?$_COOKIE["ni29"]:29;
$nini29d=isset($_COOKIE["nini29"])?$_COOKIE["nini29"]:"";
$ninini29d=isset($_COOKIE["ninini29"])?$_COOKIE["ninini29"]:"";
if($dia=="30"){//30
  if($taf=="1"){
    setcookie("ni30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini30",$maccabeus1);
  }
}
$ni30d=isset($_COOKIE["ni30"])?$_COOKIE["ni30"]:30;
$nini30d=isset($_COOKIE["nini30"])?$_COOKIE["nini30"]:"";
$ninini30d=isset($_COOKIE["ninini30"])?$_COOKIE["ninini30"]:"";
if($dia=="31"){//31
  if($taf=="1"){
    setcookie("ni31",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nini31",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("ninini31",$maccabeus1);
  }
}
$ni31d=isset($_COOKIE["ni31"])?$_COOKIE["ni31"]:31;
$nini31d=isset($_COOKIE["nini31"])?$_COOKIE["nini31"]:"";
$ninini31d=isset($_COOKIE["ninini31"])?$_COOKIE["ninini31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Março</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="nivembro.php">novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Março</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Março</p>
<p class="yoda">Olá, seja bem vindo ao caléndario, aqui se encontra as tarefas do més de Março.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada ni calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td id="1d" class="si"><?php echo"$ni1d <br> $nini1d <br> $ninini1d";?></td><td id="2d" class="se"><?php echo"$ni2d <br> $nini2d <br> $ninini2d";?></td><td id="3d" class="se"><?php echo"$ni3d <br> $nini3d <br> $ninini3d";?></td><td id="4d" class="se"><?php echo"$ni4d <br> $nini4d <br> $ninini4d";?></td><td id="5d" class="se"><?php echo"$ni5d <br> $nini5d <br> $ninini5d";?></td><td id="6d" class="se"><?php echo"$ni6d <br> $nini6d <br> $ninini6d";?></td><td id="7d" class="so"><?php echo"$ni7d <br> $nini7d <br> $ninini7d";?></td></tr>
    <tr><td id="8d" class="si"><?php echo"$ni8d <br> $nini8d <br> $ninini8d";?></td><td id="9d" class="se"><?php echo"$ni9d <br> $nini9d <br> $ninini9d";?></td><td id="10d" class="se"><?php echo"$ni10d <br> $nini10d <br> $ninini10d";?></td><td id="11d" class="se"><?php echo"$ni11d <br> $nini11d <br> $ninini11d";?></td><td id="12d" class="se"><?php echo"$ni12d <br> $nini12d <br> $ninini12d";?></td><td id="13d" class="se"><?php echo"$ni13d <br> $nini13d <br> $ninini13d";?></td><td id="14d" class="so"><?php echo"$ni14d <br> $nini14d <br> $ninini14d";?></td></tr>
    <tr><td id="15d" class="si"><?php echo"$ni15d <br> $nini15d <br> $ninini15d";?></td><td id="16d" class="se"><?php echo"$ni16d <br> $nini16d <br> $ninini16d";?></td><td id="17d" class="se"><?php echo"$ni17d <br> $nini17d <br> $ninini17d";?></td><td id="18d" class="se"><?php echo"$ni18d <br> $nini18d <br> $ninini18d";?></td><td id="19d" class="se"><?php echo"$ni19d <br> $nini19d <br> $ninini19d";?></td><td id="20d" class="se"><?php echo"$ni20d <br> $nini20d <br> $ninini20d";?></td><td id="21d" class="so"><?php echo"$ni21d <br> $nini21d <br> $ninini21d";?></td></tr>
    <tr><td id="22d" class="si"><?php echo"$ni22d <br> $nini22d <br> $ninini22d";?></td><td id="23d" class="se"><?php echo"$ni23d <br> $nini23d <br> $ninini23d";?></td><td id="24d" class="se"><?php echo"$ni24d <br> $nini24d <br> $ninini24d";?></td><td id="25d" class="se"><?php echo"$ni25d <br> $nini25d <br> $ninini25d";?></td><td id="26d" class="se"><?php echo"$ni26d <br> $nini26d <br> $ninini26d";?></td><td id="27d" class="se"><?php echo"$ni27d <br> $nini27d <br> $ninini27d";?></td><td id="28d" class="so"><?php echo"$ni28d <br> $nini28d <br> $ninini28d";?></td></tr>
    <tr><td id="29d" class="si"><?php echo"$ni29d <br> $nini29d <br> $ninini29d";?></td><td id="30d" class="se"><?php echo"$ni30d <br> $nini30d <br> $ninini30d";?></td><td id="31d" class="se"><?php echo"$ni31d <br> $nini31d <br> $ninini31d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="marco.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="32">31</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>