<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("no1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono1",$maccabeus1);
  }
}
$no1d=isset($_COOKIE["no1"])?$_COOKIE["no1"]:1;
$nono1d=isset($_COOKIE["nono1"])?$_COOKIE["nono1"]:"";
$nonono1d=isset($_COOKIE["nonono1"])?$_COOKIE["nonono1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("no2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono2",$maccabeus1);
  }
}
$no2d=isset($_COOKIE["no2"])?$_COOKIE["no2"]:2;
$nono2d=isset($_COOKIE["nono2"])?$_COOKIE["nono2"]:"";
$nonono2d=isset($_COOKIE["nonono2"])?$_COOKIE["nonono2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("no3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono3",$maccabeus1);
    $nono1d=isset($_COOKIE["nono3"])?$_COOKIE["nono3"]:"";
  }
  if($taf=="3"){
    setcookie("nonono3",$maccabeus1);
  }
}
$no3d=isset($_COOKIE["no3"])?$_COOKIE["no3"]:3;
$nono3d=isset($_COOKIE["nono3"])?$_COOKIE["nono3"]:"";
$nonono3d=isset($_COOKIE["nonono3"])?$_COOKIE["nonono3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("no4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono4",$maccabeus1);
  }
}
$no4d=isset($_COOKIE["no4"])?$_COOKIE["no4"]:4;
$nono4d=isset($_COOKIE["nono4"])?$_COOKIE["nono4"]:"";
$nonono4d=isset($_COOKIE["nonono4"])?$_COOKIE["nonono4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("no5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono5",$maccabeus1);
  }
}
$no5d=isset($_COOKIE["no5"])?$_COOKIE["no5"]:5;
$nono5d=isset($_COOKIE["nono5"])?$_COOKIE["nono5"]:"";
$nonono5d=isset($_COOKIE["nonono5"])?$_COOKIE["nonono5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("no6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono6",$maccabeus1);
  }
}
$no6d=isset($_COOKIE["no6"])?$_COOKIE["no6"]:6;
$nono6d=isset($_COOKIE["nono6"])?$_COOKIE["nono6"]:"";
$nonono6d=isset($_COOKIE["nonono6"])?$_COOKIE["nonono6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("no7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono7",$maccabeus1);
  }
}
$no7d=isset($_COOKIE["no7"])?$_COOKIE["no7"]:7;
$nono7d=isset($_COOKIE["nono7"])?$_COOKIE["nono7"]:"";
$nonono7d=isset($_COOKIE["nonono7"])?$_COOKIE["nonono7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("no8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono8",$maccabeus1);
  }
}
$no8d=isset($_COOKIE["no8"])?$_COOKIE["no8"]:8;
$nono8d=isset($_COOKIE["nono8"])?$_COOKIE["nono8"]:"";
$nonono8d=isset($_COOKIE["nonono8"])?$_COOKIE["nonono8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("no9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono9",$maccabeus1);
  }
}
$no9d=isset($_COOKIE["no9"])?$_COOKIE["no9"]:9;
$nono9d=isset($_COOKIE["nono9"])?$_COOKIE["nono9"]:"";
$nonono9d=isset($_COOKIE["nonono9"])?$_COOKIE["nonono9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("no10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono10",$maccabeus1);
  }
}
$no10d=isset($_COOKIE["no10"])?$_COOKIE["no10"]:10;
$nono10d=isset($_COOKIE["nono10"])?$_COOKIE["nono10"]:"";
$nonono10d=isset($_COOKIE["nonono10"])?$_COOKIE["nonono10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("no11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono11",$maccabeus1);
  }
}
$no11d=isset($_COOKIE["no11"])?$_COOKIE["no11"]:11;
$nono11d=isset($_COOKIE["nono11"])?$_COOKIE["nono11"]:"";
$nonono11d=isset($_COOKIE["nonono11"])?$_COOKIE["nonono11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("no12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono12",$maccabeus1);
  }
}
$no12d=isset($_COOKIE["no12"])?$_COOKIE["no12"]:12;
$nono12d=isset($_COOKIE["nono12"])?$_COOKIE["nono12"]:"";
$nonono12d=isset($_COOKIE["nonono12"])?$_COOKIE["nonono12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("no13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono13",$maccabeus1);
  }
}
$no13d=isset($_COOKIE["no13"])?$_COOKIE["no13"]:13;
$nono13d=isset($_COOKIE["nono13"])?$_COOKIE["nono13"]:"";
$nonono13d=isset($_COOKIE["nonono13"])?$_COOKIE["nonono13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("no14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono14",$maccabeus1);
  }
}
$no14d=isset($_COOKIE["no14"])?$_COOKIE["no14"]:14;
$nono14d=isset($_COOKIE["nono14"])?$_COOKIE["nono14"]:"";
$nonono14d=isset($_COOKIE["nonono14"])?$_COOKIE["nonono14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("no15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono15",$maccabeus1);
  }
}
$no15d=isset($_COOKIE["no15"])?$_COOKIE["no1"]:15;
$nono15d=isset($_COOKIE["nono15"])?$_COOKIE["nono15"]:"";
$nonono15d=isset($_COOKIE["nonono15"])?$_COOKIE["nonono15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("no16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono16",$maccabeus1);
  }
}
$no16d=isset($_COOKIE["no16"])?$_COOKIE["no16"]:16;
$nono16d=isset($_COOKIE["nono16"])?$_COOKIE["nono16"]:"";
$nonono16d=isset($_COOKIE["nonono16"])?$_COOKIE["nonono16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("no17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono17",$maccabeus1);
  }
}
$no17d=isset($_COOKIE["no17"])?$_COOKIE["no17"]:17;
$nono17d=isset($_COOKIE["nono17"])?$_COOKIE["nono17"]:"";
$nonono17d=isset($_COOKIE["nonono17"])?$_COOKIE["nonono17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("no18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono18",$maccabeus1);
  }
}
$no18d=isset($_COOKIE["no18"])?$_COOKIE["no18"]:18;
$nono18d=isset($_COOKIE["nono18"])?$_COOKIE["nono18"]:"";
$nonono18d=isset($_COOKIE["nonono18"])?$_COOKIE["nonono18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("no19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono19",$maccabeus1);
  }
}
$no19d=isset($_COOKIE["no19"])?$_COOKIE["no19"]:19;
$nono19d=isset($_COOKIE["nono19"])?$_COOKIE["nono19"]:"";
$nonono19d=isset($_COOKIE["nonono19"])?$_COOKIE["nonono19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("no2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono2",$maccabeus1);
  }
}
$no20d=isset($_COOKIE["no2"])?$_COOKIE["no2"]:20;
$nono20d=isset($_COOKIE["nono2"])?$_COOKIE["nono2"]:"";
$nonono20d=isset($_COOKIE["nonono2"])?$_COOKIE["nonono2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("no21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono21",$maccabeus1);
  }
}
$no21d=isset($_COOKIE["no21"])?$_COOKIE["no21"]:21;
$nono21d=isset($_COOKIE["nono21"])?$_COOKIE["nono21"]:"";
$nonono21d=isset($_COOKIE["nonono21"])?$_COOKIE["nonono21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("no22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono22",$maccabeus1);
  }
}
$no22d=isset($_COOKIE["no22"])?$_COOKIE["no22"]:22;
$nono22d=isset($_COOKIE["nono22"])?$_COOKIE["nono22"]:"";
$nonono22d=isset($_COOKIE["nonono22"])?$_COOKIE["nonono22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("no23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono23",$maccabeus1);
  }
}
$no23d=isset($_COOKIE["no23"])?$_COOKIE["no23"]:23;
$nono23d=isset($_COOKIE["nono23"])?$_COOKIE["nono23"]:"";
$nonono23d=isset($_COOKIE["nonono23"])?$_COOKIE["nonono23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("no24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono24",$maccabeus1);
  }
}
$no24d=isset($_COOKIE["no24"])?$_COOKIE["no24"]:24;
$nono24d=isset($_COOKIE["nono24"])?$_COOKIE["nono24"]:"";
$nonono24d=isset($_COOKIE["nonono24"])?$_COOKIE["nonono24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("no25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono25",$maccabeus1);
  }
}
$no25d=isset($_COOKIE["no25"])?$_COOKIE["no25"]:25;
$nono25d=isset($_COOKIE["nono25"])?$_COOKIE["nono25"]:"";
$nonono25d=isset($_COOKIE["nonono25"])?$_COOKIE["nonono25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("no26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono26",$maccabeus1);
  }
}
$no26d=isset($_COOKIE["no26"])?$_COOKIE["no26"]:26;
$nono26d=isset($_COOKIE["nono26"])?$_COOKIE["nono26"]:"";
$nonono26d=isset($_COOKIE["nonono26"])?$_COOKIE["nonono26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("no27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono27",$maccabeus1);
  }
}
$no27d=isset($_COOKIE["no27"])?$_COOKIE["no27"]:27;
$nono27d=isset($_COOKIE["nono27"])?$_COOKIE["nono27"]:"";
$nonono27d=isset($_COOKIE["nonono27"])?$_COOKIE["nonono27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("no28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono28",$maccabeus1);
  }
}
$no28d=isset($_COOKIE["no28"])?$_COOKIE["no28"]:28;
$nono28d=isset($_COOKIE["nono28"])?$_COOKIE["nono28"]:"";
$nonono28d=isset($_COOKIE["nonono28"])?$_COOKIE["nonono28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("no29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono29",$maccabeus1);
  }
}
$no29d=isset($_COOKIE["no29"])?$_COOKIE["no29"]:29;
$nono29d=isset($_COOKIE["nono29"])?$_COOKIE["nono29"]:"";
$nonono29d=isset($_COOKIE["nonono29"])?$_COOKIE["nonono29"]:"";
if($dia=="30"){//30
  if($taf=="1"){
    setcookie("no30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("nono30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("nonono30",$maccabeus1);
  }
}
$no30d=isset($_COOKIE["no30"])?$_COOKIE["no30"]:30;
$nono30d=isset($_COOKIE["nono30"])?$_COOKIE["nono30"]:"";
$nonono30d=isset($_COOKIE["nonono30"])?$_COOKIE["nonono30"]:"";
// if($dia=="31"){//31
//   if($taf=="1"){
//     setcookie("no31",$maccabeus1);
//   }
//   if($taf=="2"){
//     setcookie("nono31",$maccabeus1);
//   }
//   if($taf=="3"){
//     setcookie("nonono31",$maccabeus1);
//   }
// }
// $no31d=isset($_COOKIE["no31"])?$_COOKIE["no31"]:31;
// $nono31d=isset($_COOKIE["nono31"])?$_COOKIE["nono31"]:"";
// $nonono31d=isset($_COOKIE["nonono31"])?$_COOKIE["nonono31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Novembro</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Novembro</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Novembro</p>
<p class="yoda">Olá, seja bem vindo ao caléndario, aqui se encontra as tarefas do més de Novembro.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td id="1d" class="si"><?php echo"$no1d <br> $nono1d <br> $nonono1d";?></td><td id="2d" class="se"><?php echo"$no2d <br> $nono2d <br> $nonono2d";?></td><td id="3d" class="se"><?php echo"$no3d <br> $nono3d <br> $nonono3d";?></td><td id="4d" class="se"><?php echo"$no4d <br> $nono4d <br> $nonono4d";?></td><td id="5d" class="se"><?php echo"$no5d <br> $nono5d <br> $nonono5d";?></td><td id="6d" class="se"><?php echo"$no6d <br> $nono6d <br> $nonono6d";?></td><td id="7d" class="so"><?php echo"$no7d <br> $nono7d <br> $nonono7d";?></td></tr>
    <tr><td id="8d" class="si"><?php echo"$no8d <br> $nono8d <br> $nonono8d";?></td><td id="9d" class="se"><?php echo"$no9d <br> $nono9d <br> $nonono9d";?></td><td id="10d" class="se"><?php echo"$no10d <br> $nono10d <br> $nonono10d";?></td><td id="11d" class="se"><?php echo"$no11d <br> $nono11d <br> $nonono11d";?></td><td id="12d" class="se"><?php echo"$no12d <br> $nono12d <br> $nonono12d";?></td><td id="13d" class="se"><?php echo"$no13d <br> $nono13d <br> $nonono13d";?></td><td id="14d" class="so"><?php echo"$no14d <br> $nono14d <br> $nonono14d";?></td></tr>
    <tr><td id="15d" class="si"><?php echo"$no15d <br> $nono15d <br> $nonono15d";?></td><td id="16d" class="se"><?php echo"$no16d <br> $nono16d <br> $nonono16d";?></td><td id="17d" class="se"><?php echo"$no17d <br> $nono17d <br> $nonono17d";?></td><td id="18d" class="se"><?php echo"$no18d <br> $nono18d <br> $nonono18d";?></td><td id="19d" class="se"><?php echo"$no19d <br> $nono19d <br> $nonono19d";?></td><td id="20d" class="se"><?php echo"$no20d <br> $nono20d <br> $nonono20d";?></td><td id="21d" class="so"><?php echo"$no21d <br> $nono21d <br> $nonono21d";?></td></tr>
    <tr><td id="22d" class="si"><?php echo"$no22d <br> $nono22d <br> $nonono22d";?></td><td id="23d" class="se"><?php echo"$no23d <br> $nono23d <br> $nonono23d";?></td><td id="24d" class="se"><?php echo"$no24d <br> $nono24d <br> $nonono24d";?></td><td id="25d" class="se"><?php echo"$no25d <br> $nono25d <br> $nonono25d";?></td><td id="26d" class="se"><?php echo"$no26d <br> $nono26d <br> $nonono26d";?></td><td id="27d" class="se"><?php echo"$no27d <br> $nono27d <br> $nonono27d";?></td><td id="28d" class="so"><?php echo"$no28d <br> $nono28d <br> $nonono28d";?></td></tr>
    <tr><td id="29d" class="si"><?php echo"$no29d <br> $nono29d <br> $nonono29d";?></td><td id="30d" class="se"><?php echo"$no30d <br> $nono30d <br> $nonono30d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="novembro.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>