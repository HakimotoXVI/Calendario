<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("rz1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz1",$maccabeus1);
  }
}
$rz1d=isset($_COOKIE["rz1"])?$_COOKIE["rz1"]:1;
$rzrz1d=isset($_COOKIE["rzrz1"])?$_COOKIE["rzrz1"]:"";
$rzrzrz1d=isset($_COOKIE["rzrzrz1"])?$_COOKIE["rzrzrz1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("rz2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz2",$maccabeus1);
  }
}
$rz2d=isset($_COOKIE["rz2"])?$_COOKIE["rz2"]:2;
$rzrz2d=isset($_COOKIE["rzrz2"])?$_COOKIE["rzrz2"]:"";
$rzrzrz2d=isset($_COOKIE["rzrzrz2"])?$_COOKIE["rzrzrz2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("rz3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz3",$maccabeus1);
    $rzrz1d=isset($_COOKIE["rzrz3"])?$_COOKIE["rzrz3"]:"";
  }
  if($taf=="3"){
    setcookie("rzrzrz3",$maccabeus1);
  }
}
$rz3d=isset($_COOKIE["rz3"])?$_COOKIE["rz3"]:3;
$rzrz3d=isset($_COOKIE["rzrz3"])?$_COOKIE["rzrz3"]:"";
$rzrzrz3d=isset($_COOKIE["rzrzrz3"])?$_COOKIE["rzrzrz3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("rz4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz4",$maccabeus1);
  }
}
$rz4d=isset($_COOKIE["rz4"])?$_COOKIE["rz4"]:4;
$rzrz4d=isset($_COOKIE["rzrz4"])?$_COOKIE["rzrz4"]:"";
$rzrzrz4d=isset($_COOKIE["rzrzrz4"])?$_COOKIE["rzrzrz4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("rz5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz5",$maccabeus1);
  }
}
$rz5d=isset($_COOKIE["rz5"])?$_COOKIE["rz5"]:5;
$rzrz5d=isset($_COOKIE["rzrz5"])?$_COOKIE["rzrz5"]:"";
$rzrzrz5d=isset($_COOKIE["rzrzrz5"])?$_COOKIE["rzrzrz5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("rz6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz6",$maccabeus1);
  }
}
$rz6d=isset($_COOKIE["rz6"])?$_COOKIE["rz6"]:6;
$rzrz6d=isset($_COOKIE["rzrz6"])?$_COOKIE["rzrz6"]:"";
$rzrzrz6d=isset($_COOKIE["rzrzrz6"])?$_COOKIE["rzrzrz6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("rz7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz7",$maccabeus1);
  }
}
$rz7d=isset($_COOKIE["rz7"])?$_COOKIE["rz7"]:7;
$rzrz7d=isset($_COOKIE["rzrz7"])?$_COOKIE["rzrz7"]:"";
$rzrzrz7d=isset($_COOKIE["rzrzrz7"])?$_COOKIE["rzrzrz7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("rz8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz8",$maccabeus1);
  }
}
$rz8d=isset($_COOKIE["rz8"])?$_COOKIE["rz8"]:8;
$rzrz8d=isset($_COOKIE["rzrz8"])?$_COOKIE["rzrz8"]:"";
$rzrzrz8d=isset($_COOKIE["rzrzrz8"])?$_COOKIE["rzrzrz8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("rz9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz9",$maccabeus1);
  }
}
$rz9d=isset($_COOKIE["rz9"])?$_COOKIE["rz9"]:9;
$rzrz9d=isset($_COOKIE["rzrz9"])?$_COOKIE["rzrz9"]:"";
$rzrzrz9d=isset($_COOKIE["rzrzrz9"])?$_COOKIE["rzrzrz9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("rz10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz10",$maccabeus1);
  }
}
$rz10d=isset($_COOKIE["rz10"])?$_COOKIE["rz10"]:10;
$rzrz10d=isset($_COOKIE["rzrz10"])?$_COOKIE["rzrz10"]:"";
$rzrzrz10d=isset($_COOKIE["rzrzrz10"])?$_COOKIE["rzrzrz10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("rz11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz11",$maccabeus1);
  }
}
$rz11d=isset($_COOKIE["rz11"])?$_COOKIE["rz11"]:11;
$rzrz11d=isset($_COOKIE["rzrz11"])?$_COOKIE["rzrz11"]:"";
$rzrzrz11d=isset($_COOKIE["rzrzrz11"])?$_COOKIE["rzrzrz11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("rz12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz12",$maccabeus1);
  }
}
$rz12d=isset($_COOKIE["rz12"])?$_COOKIE["rz12"]:12;
$rzrz12d=isset($_COOKIE["rzrz12"])?$_COOKIE["rzrz12"]:"";
$rzrzrz12d=isset($_COOKIE["rzrzrz12"])?$_COOKIE["rzrzrz12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("rz13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz13",$maccabeus1);
  }
}
$rz13d=isset($_COOKIE["rz13"])?$_COOKIE["rz13"]:13;
$rzrz13d=isset($_COOKIE["rzrz13"])?$_COOKIE["rzrz13"]:"";
$rzrzrz13d=isset($_COOKIE["rzrzrz13"])?$_COOKIE["rzrzrz13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("rz14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz14",$maccabeus1);
  }
}
$rz14d=isset($_COOKIE["rz14"])?$_COOKIE["rz14"]:14;
$rzrz14d=isset($_COOKIE["rzrz14"])?$_COOKIE["rzrz14"]:"";
$rzrzrz14d=isset($_COOKIE["rzrzrz14"])?$_COOKIE["rzrzrz14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("rz15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz15",$maccabeus1);
  }
}
$rz15d=isset($_COOKIE["rz15"])?$_COOKIE["rz1"]:15;
$rzrz15d=isset($_COOKIE["rzrz15"])?$_COOKIE["rzrz15"]:"";
$rzrzrz15d=isset($_COOKIE["rzrzrz15"])?$_COOKIE["rzrzrz15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("rz16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz16",$maccabeus1);
  }
}
$rz16d=isset($_COOKIE["rz16"])?$_COOKIE["rz16"]:16;
$rzrz16d=isset($_COOKIE["rzrz16"])?$_COOKIE["rzrz16"]:"";
$rzrzrz16d=isset($_COOKIE["rzrzrz16"])?$_COOKIE["rzrzrz16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("rz17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz17",$maccabeus1);
  }
}
$rz17d=isset($_COOKIE["rz17"])?$_COOKIE["rz17"]:17;
$rzrz17d=isset($_COOKIE["rzrz17"])?$_COOKIE["rzrz17"]:"";
$rzrzrz17d=isset($_COOKIE["rzrzrz17"])?$_COOKIE["rzrzrz17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("rz18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz18",$maccabeus1);
  }
}
$rz18d=isset($_COOKIE["rz18"])?$_COOKIE["rz18"]:18;
$rzrz18d=isset($_COOKIE["rzrz18"])?$_COOKIE["rzrz18"]:"";
$rzrzrz18d=isset($_COOKIE["rzrzrz18"])?$_COOKIE["rzrzrz18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("rz19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz19",$maccabeus1);
  }
}
$rz19d=isset($_COOKIE["rz19"])?$_COOKIE["rz19"]:19;
$rzrz19d=isset($_COOKIE["rzrz19"])?$_COOKIE["rzrz19"]:"";
$rzrzrz19d=isset($_COOKIE["rzrzrz19"])?$_COOKIE["rzrzrz19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("rz2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz2",$maccabeus1);
  }
}
$rz20d=isset($_COOKIE["rz2"])?$_COOKIE["rz2"]:20;
$rzrz20d=isset($_COOKIE["rzrz2"])?$_COOKIE["rzrz2"]:"";
$rzrzrz20d=isset($_COOKIE["rzrzrz2"])?$_COOKIE["rzrzrz2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("rz21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz21",$maccabeus1);
  }
}
$rz21d=isset($_COOKIE["rz21"])?$_COOKIE["rz21"]:21;
$rzrz21d=isset($_COOKIE["rzrz21"])?$_COOKIE["rzrz21"]:"";
$rzrzrz21d=isset($_COOKIE["rzrzrz21"])?$_COOKIE["rzrzrz21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("rz22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz22",$maccabeus1);
  }
}
$rz22d=isset($_COOKIE["rz22"])?$_COOKIE["rz22"]:22;
$rzrz22d=isset($_COOKIE["rzrz22"])?$_COOKIE["rzrz22"]:"";
$rzrzrz22d=isset($_COOKIE["rzrzrz22"])?$_COOKIE["rzrzrz22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("rz23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz23",$maccabeus1);
  }
}
$rz23d=isset($_COOKIE["rz23"])?$_COOKIE["rz23"]:23;
$rzrz23d=isset($_COOKIE["rzrz23"])?$_COOKIE["rzrz23"]:"";
$rzrzrz23d=isset($_COOKIE["rzrzrz23"])?$_COOKIE["rzrzrz23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("rz24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz24",$maccabeus1);
  }
}
$rz24d=isset($_COOKIE["rz24"])?$_COOKIE["rz24"]:24;
$rzrz24d=isset($_COOKIE["rzrz24"])?$_COOKIE["rzrz24"]:"";
$rzrzrz24d=isset($_COOKIE["rzrzrz24"])?$_COOKIE["rzrzrz24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("rz25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz25",$maccabeus1);
  }
}
$rz25d=isset($_COOKIE["rz25"])?$_COOKIE["rz25"]:25;
$rzrz25d=isset($_COOKIE["rzrz25"])?$_COOKIE["rzrz25"]:"";
$rzrzrz25d=isset($_COOKIE["rzrzrz25"])?$_COOKIE["rzrzrz25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("rz26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz26",$maccabeus1);
  }
}
$rz26d=isset($_COOKIE["rz26"])?$_COOKIE["rz26"]:26;
$rzrz26d=isset($_COOKIE["rzrz26"])?$_COOKIE["rzrz26"]:"";
$rzrzrz26d=isset($_COOKIE["rzrzrz26"])?$_COOKIE["rzrzrz26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("rz27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz27",$maccabeus1);
  }
}
$rz27d=isset($_COOKIE["rz27"])?$_COOKIE["rz27"]:27;
$rzrz27d=isset($_COOKIE["rzrz27"])?$_COOKIE["rzrz27"]:"";
$rzrzrz27d=isset($_COOKIE["rzrzrz27"])?$_COOKIE["rzrzrz27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("rz28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz28",$maccabeus1);
  }
}
$rz28d=isset($_COOKIE["rz28"])?$_COOKIE["rz28"]:28;
$rzrz28d=isset($_COOKIE["rzrz28"])?$_COOKIE["rzrz28"]:"";
$rzrzrz28d=isset($_COOKIE["rzrzrz28"])?$_COOKIE["rzrzrz28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("rz29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz29",$maccabeus1);
  }
}
$rz29d=isset($_COOKIE["rz29"])?$_COOKIE["rz29"]:29;
$rzrz29d=isset($_COOKIE["rzrz29"])?$_COOKIE["rzrz29"]:"";
$rzrzrz29d=isset($_COOKIE["rzrzrz29"])?$_COOKIE["rzrzrz29"]:"";
if($dia=="30"){//30
  if($taf=="1"){
    setcookie("rz30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("rzrz30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("rzrzrz30",$maccabeus1);
  }
}
$rz30d=isset($_COOKIE["rz30"])?$_COOKIE["rz30"]:30;
$rzrz30d=isset($_COOKIE["rzrz30"])?$_COOKIE["rzrz30"]:"";
$rzrzrz30d=isset($_COOKIE["rzrzrz30"])?$_COOKIE["rzrzrz30"]:"";
// if($dia=="31"){//31
//   if($taf=="1"){
//     setcookie("rz31",$maccabeus1);
//   }
//   if($taf=="2"){
//     setcookie("rzrz31",$maccabeus1);
//   }
//   if($taf=="3"){
//     setcookie("rzrzrz31",$maccabeus1);
//   }
// }
// $rz31d=isset($_COOKIE["rz31"])?$_COOKIE["rz31"]:31;
// $rzrz31d=isset($_COOKIE["rzrz31"])?$_COOKIE["rzrz31"]:"";
// $rzrzrz31d=isset($_COOKIE["rzrzrz31"])?$_COOKIE["rzrzrz31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Setembro</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Setembro</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Setembro</p>
<p class="yoda">Olá, seja bem vindo ao caléndario, aqui se encontra as tarefas do més de Setembro.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td id="1d" class="si"><?php echo"";?></td><td id="2d" class="se"><?php echo"";?></td><td id="1d" class="se"><?php echo"$rz1d <br> $rzrz1d <br> $rzrzrz1d";?></td><td id="2d" class="se"><?php echo"$rz2d <br> $rzrz2d <br> $rzrzrz2d";?></td><td id="3d" class="se"><?php echo"$rz3d <br> $rzrz3d <br> $rzrzrz3d";?></td><td id="4d" class="se"><?php echo"$rz4d <br> $rzrz4d <br> $rzrzrz4d";?></td><td id="5d" class="so"><?php echo"$rz5d <br> $rzrz5d <br> $rzrzrz5d";?></td></tr>
    <tr><td id="6d" class="si"><?php echo"$rz6d <br> $rzrz6d <br> $rzrzrz6d";?></td><td id="7d" class="se"><?php echo"$rz7d <br> $rzrz7d <br> $rzrzrz7d";?></td><td id="8d" class="se"><?php echo"$rz8d <br> $rzrz8d <br> $rzrzrz8d";?></td><td id="9d" class="se"><?php echo"$rz9d <br> $rzrz9d <br> $rzrzrz9d";?></td><td id="10d" class="se"><?php echo"$rz10d <br> $rzrz10d <br> $rzrzrz10d";?></td><td id="11d" class="se"><?php echo"$rz11d <br> $rzrz11d <br> $rzrzrz11d";?></td><td id="12d" class="so"><?php echo"$rz12d <br> $rzrz12d <br> $rzrzrz12d";?></td></tr>
    <tr><td id="13d" class="si"><?php echo"$rz13d <br> $rzrz13d <br> $rzrzrz13d";?></td><td id="14d" class="se"><?php echo"$rz14d <br> $rzrz14d <br> $rzrzrz14d";?></td><td id="15d" class="se"><?php echo"$rz15d <br> $rzrz15d <br> $rzrzrz15d";?></td><td id="16d" class="se"><?php echo"$rz16d <br> $rzrz16d <br> $rzrzrz16d";?></td><td id="17d" class="se"><?php echo"$rz17d <br> $rzrz17d <br> $rzrzrz17d";?></td><td id="18d" class="se"><?php echo"$rz18d <br> $rzrz18d <br> $rzrzrz18d";?></td><td id="19d" class="so"><?php echo"$rz19d <br> $rzrz19d <br> $rzrzrz19d";?></td></tr>
    <tr><td id="20d" class="si"><?php echo"$rz20d <br> $rzrz20d <br> $rzrzrz20d";?></td><td id="21d" class="se"><?php echo"$rz21d <br> $rzrz21d <br> $rzrzrz21d";?></td><td id="22d" class="se"><?php echo"$rz22d <br> $rzrz22d <br> $rzrzrz22d";?></td><td id="23d" class="se"><?php echo"$rz23d <br> $rzrz23d <br> $rzrzrz23d";?></td><td id="24d" class="se"><?php echo"$rz24d <br> $rzrz24d <br> $rzrzrz24d";?></td><td id="25d" class="se"><?php echo"$rz25d <br> $rzrz25d <br> $rzrzrz25d";?></td><td id="26d" class="so"><?php echo"$rz26d <br> $rzrz26d <br> $rzrzrz26d";?></td></tr>
    <tr><td id="27d" class="si"><?php echo"$rz27d <br> $rzrz27d <br> $rzrzrz27d";?></td><td id="28d" class="se"><?php echo"$rz28d <br> $rzrz28d <br> $rzrzrz28d";?></td><td id="29d" class="se"><?php echo"$rz29d <br> $rzrz29d <br> $rzrzrz29d";?></td><td id="30d" class="se"><?php echo"$rz30d <br> $rzrz30d <br> $rzrzrz30d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="setembro.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>