<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("zy1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy1",$maccabeus1);
  }
}
$zy1d=isset($_COOKIE["zy1"])?$_COOKIE["zy1"]:1;
$zyzy1d=isset($_COOKIE["zyzy1"])?$_COOKIE["zyzy1"]:"";
$zyzyzy1d=isset($_COOKIE["zyzyzy1"])?$_COOKIE["zyzyzy1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("zy2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy2",$maccabeus1);
  }
}
$zy2d=isset($_COOKIE["zy2"])?$_COOKIE["zy2"]:2;
$zyzy2d=isset($_COOKIE["zyzy2"])?$_COOKIE["zyzy2"]:"";
$zyzyzy2d=isset($_COOKIE["zyzyzy2"])?$_COOKIE["zyzyzy2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("zy3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy3",$maccabeus1);
    $zyzy1d=isset($_COOKIE["zyzy3"])?$_COOKIE["zyzy3"]:"";
  }
  if($taf=="3"){
    setcookie("zyzyzy3",$maccabeus1);
  }
}
$zy3d=isset($_COOKIE["zy3"])?$_COOKIE["zy3"]:3;
$zyzy3d=isset($_COOKIE["zyzy3"])?$_COOKIE["zyzy3"]:"";
$zyzyzy3d=isset($_COOKIE["zyzyzy3"])?$_COOKIE["zyzyzy3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("zy4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy4",$maccabeus1);
  }
}
$zy4d=isset($_COOKIE["zy4"])?$_COOKIE["zy4"]:4;
$zyzy4d=isset($_COOKIE["zyzy4"])?$_COOKIE["zyzy4"]:"";
$zyzyzy4d=isset($_COOKIE["zyzyzy4"])?$_COOKIE["zyzyzy4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("zy5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy5",$maccabeus1);
  }
}
$zy5d=isset($_COOKIE["zy5"])?$_COOKIE["zy5"]:5;
$zyzy5d=isset($_COOKIE["zyzy5"])?$_COOKIE["zyzy5"]:"";
$zyzyzy5d=isset($_COOKIE["zyzyzy5"])?$_COOKIE["zyzyzy5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("zy6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy6",$maccabeus1);
  }
}
$zy6d=isset($_COOKIE["zy6"])?$_COOKIE["zy6"]:6;
$zyzy6d=isset($_COOKIE["zyzy6"])?$_COOKIE["zyzy6"]:"";
$zyzyzy6d=isset($_COOKIE["zyzyzy6"])?$_COOKIE["zyzyzy6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("zy7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy7",$maccabeus1);
  }
}
$zy7d=isset($_COOKIE["zy7"])?$_COOKIE["zy7"]:7;
$zyzy7d=isset($_COOKIE["zyzy7"])?$_COOKIE["zyzy7"]:"";
$zyzyzy7d=isset($_COOKIE["zyzyzy7"])?$_COOKIE["zyzyzy7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("zy8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy8",$maccabeus1);
  }
}
$zy8d=isset($_COOKIE["zy8"])?$_COOKIE["zy8"]:8;
$zyzy8d=isset($_COOKIE["zyzy8"])?$_COOKIE["zyzy8"]:"";
$zyzyzy8d=isset($_COOKIE["zyzyzy8"])?$_COOKIE["zyzyzy8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("zy9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy9",$maccabeus1);
  }
}
$zy9d=isset($_COOKIE["zy9"])?$_COOKIE["zy9"]:9;
$zyzy9d=isset($_COOKIE["zyzy9"])?$_COOKIE["zyzy9"]:"";
$zyzyzy9d=isset($_COOKIE["zyzyzy9"])?$_COOKIE["zyzyzy9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("zy10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy10",$maccabeus1);
  }
}
$zy10d=isset($_COOKIE["zy10"])?$_COOKIE["zy10"]:10;
$zyzy10d=isset($_COOKIE["zyzy10"])?$_COOKIE["zyzy10"]:"";
$zyzyzy10d=isset($_COOKIE["zyzyzy10"])?$_COOKIE["zyzyzy10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("zy11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy11",$maccabeus1);
  }
}
$zy11d=isset($_COOKIE["zy11"])?$_COOKIE["zy11"]:11;
$zyzy11d=isset($_COOKIE["zyzy11"])?$_COOKIE["zyzy11"]:"";
$zyzyzy11d=isset($_COOKIE["zyzyzy11"])?$_COOKIE["zyzyzy11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("zy12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy12",$maccabeus1);
  }
}
$zy12d=isset($_COOKIE["zy12"])?$_COOKIE["zy12"]:12;
$zyzy12d=isset($_COOKIE["zyzy12"])?$_COOKIE["zyzy12"]:"";
$zyzyzy12d=isset($_COOKIE["zyzyzy12"])?$_COOKIE["zyzyzy12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("zy13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy13",$maccabeus1);
  }
}
$zy13d=isset($_COOKIE["zy13"])?$_COOKIE["zy13"]:13;
$zyzy13d=isset($_COOKIE["zyzy13"])?$_COOKIE["zyzy13"]:"";
$zyzyzy13d=isset($_COOKIE["zyzyzy13"])?$_COOKIE["zyzyzy13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("zy14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy14",$maccabeus1);
  }
}
$zy14d=isset($_COOKIE["zy14"])?$_COOKIE["zy14"]:14;
$zyzy14d=isset($_COOKIE["zyzy14"])?$_COOKIE["zyzy14"]:"";
$zyzyzy14d=isset($_COOKIE["zyzyzy14"])?$_COOKIE["zyzyzy14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("zy15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy15",$maccabeus1);
  }
}
$zy15d=isset($_COOKIE["zy15"])?$_COOKIE["zy1"]:15;
$zyzy15d=isset($_COOKIE["zyzy15"])?$_COOKIE["zyzy15"]:"";
$zyzyzy15d=isset($_COOKIE["zyzyzy15"])?$_COOKIE["zyzyzy15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("zy16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy16",$maccabeus1);
  }
}
$zy16d=isset($_COOKIE["zy16"])?$_COOKIE["zy16"]:16;
$zyzy16d=isset($_COOKIE["zyzy16"])?$_COOKIE["zyzy16"]:"";
$zyzyzy16d=isset($_COOKIE["zyzyzy16"])?$_COOKIE["zyzyzy16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("zy17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy17",$maccabeus1);
  }
}
$zy17d=isset($_COOKIE["zy17"])?$_COOKIE["zy17"]:17;
$zyzy17d=isset($_COOKIE["zyzy17"])?$_COOKIE["zyzy17"]:"";
$zyzyzy17d=isset($_COOKIE["zyzyzy17"])?$_COOKIE["zyzyzy17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("zy18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy18",$maccabeus1);
  }
}
$zy18d=isset($_COOKIE["zy18"])?$_COOKIE["zy18"]:18;
$zyzy18d=isset($_COOKIE["zyzy18"])?$_COOKIE["zyzy18"]:"";
$zyzyzy18d=isset($_COOKIE["zyzyzy18"])?$_COOKIE["zyzyzy18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("zy19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy19",$maccabeus1);
  }
}
$zy19d=isset($_COOKIE["zy19"])?$_COOKIE["zy19"]:19;
$zyzy19d=isset($_COOKIE["zyzy19"])?$_COOKIE["zyzy19"]:"";
$zyzyzy19d=isset($_COOKIE["zyzyzy19"])?$_COOKIE["zyzyzy19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("zy2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy2",$maccabeus1);
  }
}
$zy20d=isset($_COOKIE["zy2"])?$_COOKIE["zy2"]:20;
$zyzy20d=isset($_COOKIE["zyzy2"])?$_COOKIE["zyzy2"]:"";
$zyzyzy20d=isset($_COOKIE["zyzyzy2"])?$_COOKIE["zyzyzy2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("zy21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy21",$maccabeus1);
  }
}
$zy21d=isset($_COOKIE["zy21"])?$_COOKIE["zy21"]:21;
$zyzy21d=isset($_COOKIE["zyzy21"])?$_COOKIE["zyzy21"]:"";
$zyzyzy21d=isset($_COOKIE["zyzyzy21"])?$_COOKIE["zyzyzy21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("zy22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy22",$maccabeus1);
  }
}
$zy22d=isset($_COOKIE["zy22"])?$_COOKIE["zy22"]:22;
$zyzy22d=isset($_COOKIE["zyzy22"])?$_COOKIE["zyzy22"]:"";
$zyzyzy22d=isset($_COOKIE["zyzyzy22"])?$_COOKIE["zyzyzy22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("zy23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy23",$maccabeus1);
  }
}
$zy23d=isset($_COOKIE["zy23"])?$_COOKIE["zy23"]:23;
$zyzy23d=isset($_COOKIE["zyzy23"])?$_COOKIE["zyzy23"]:"";
$zyzyzy23d=isset($_COOKIE["zyzyzy23"])?$_COOKIE["zyzyzy23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("zy24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy24",$maccabeus1);
  }
}
$zy24d=isset($_COOKIE["zy24"])?$_COOKIE["zy24"]:24;
$zyzy24d=isset($_COOKIE["zyzy24"])?$_COOKIE["zyzy24"]:"";
$zyzyzy24d=isset($_COOKIE["zyzyzy24"])?$_COOKIE["zyzyzy24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("zy25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy25",$maccabeus1);
  }
}
$zy25d=isset($_COOKIE["zy25"])?$_COOKIE["zy25"]:25;
$zyzy25d=isset($_COOKIE["zyzy25"])?$_COOKIE["zyzy25"]:"";
$zyzyzy25d=isset($_COOKIE["zyzyzy25"])?$_COOKIE["zyzyzy25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("zy26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy26",$maccabeus1);
  }
}
$zy26d=isset($_COOKIE["zy26"])?$_COOKIE["zy26"]:26;
$zyzy26d=isset($_COOKIE["zyzy26"])?$_COOKIE["zyzy26"]:"";
$zyzyzy26d=isset($_COOKIE["zyzyzy26"])?$_COOKIE["zyzyzy26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("zy27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy27",$maccabeus1);
  }
}
$zy27d=isset($_COOKIE["zy27"])?$_COOKIE["zy27"]:27;
$zyzy27d=isset($_COOKIE["zyzy27"])?$_COOKIE["zyzy27"]:"";
$zyzyzy27d=isset($_COOKIE["zyzyzy27"])?$_COOKIE["zyzyzy27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("zy28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy28",$maccabeus1);
  }
}
$zy28d=isset($_COOKIE["zy28"])?$_COOKIE["zy28"]:28;
$zyzy28d=isset($_COOKIE["zyzy28"])?$_COOKIE["zyzy28"]:"";
$zyzyzy28d=isset($_COOKIE["zyzyzy28"])?$_COOKIE["zyzyzy28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("zy29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy29",$maccabeus1);
  }
}
$zy29d=isset($_COOKIE["zy29"])?$_COOKIE["zy29"]:29;
$zyzy29d=isset($_COOKIE["zyzy29"])?$_COOKIE["zyzy29"]:"";
$zyzyzy29d=isset($_COOKIE["zyzyzy29"])?$_COOKIE["zyzyzy29"]:"";
if($dia=="30"){//30
  if($taf=="1"){
    setcookie("zy30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy30",$maccabeus1);
  }
}
$zy30d=isset($_COOKIE["zy30"])?$_COOKIE["zy30"]:30;
$zyzy30d=isset($_COOKIE["zyzy30"])?$_COOKIE["zyzy30"]:"";
$zyzyzy30d=isset($_COOKIE["zyzyzy30"])?$_COOKIE["zyzyzy30"]:"";
if($dia=="31"){//31
  if($taf=="1"){
    setcookie("zy31",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zyzy31",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zyzyzy31",$maccabeus1);
  }
}
$zy31d=isset($_COOKIE["zy31"])?$_COOKIE["zy31"]:31;
$zyzy31d=isset($_COOKIE["zyzy31"])?$_COOKIE["zyzy31"]:"";
$zyzyzy31d=isset($_COOKIE["zyzyzy31"])?$_COOKIE["zyzyzy31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Agosto</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Agosto</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Agosto</p>
<p class="yoda">Olá, seja bem vindo ao caléndario, aqui se encontra as tarefas do més de Agosto.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td class="si"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td id="1d" class="so"><?php echo"$zy1d <br> $zyzy1d <br> $zyzyzy1d";?></td></tr>
    <tr><td id="2d" class="si"><?php echo"$zy2d <br> $zyzy2d <br> $zyzyzy2d";?></td><td id="3d" class="se"><?php echo"$zy3d <br> $zyzy3d <br> $zyzyzy3d";?></td><td id="4d" class="se"><?php echo"$zy4d <br> $zyzy4d <br> $zyzyzy4d";?></td><td id="5d" class="se"><?php echo"$zy5d <br> $zyzy5d <br> $zyzyzy5d";?></td><td id="6d" class="se"><?php echo"$zy6d <br> $zyzy6d <br> $zyzyzy6d";?></td><td id="7d" class="se"><?php echo"$zy7d <br> $zyzy7d <br> $zyzyzy7d";?></td><td id="8d" class="so"><?php echo"$zy8d <br> $zyzy8d <br> $zyzyzy8d";?></td></tr>
    <tr><td id="9d" class="si"><?php echo"$zy9d <br> $zyzy9d <br> $zyzyzy9d";?></td><td id="10d" class="se"><?php echo"$zy10d <br> $zyzy10d <br> $zyzyzy10d";?></td><td id="11d" class="se"><?php echo"$zy11d <br> $zyzy11d <br> $zyzyzy11d";?></td><td id="12d" class="se"><?php echo"$zy12d <br> $zyzy12d <br> $zyzyzy12d";?></td><td id="13d" class="se"><?php echo"$zy13d <br> $zyzy13d <br> $zyzyzy13d";?></td><td id="14d" class="se"><?php echo"$zy14d <br> $zyzy14d <br> $zyzyzy14d";?></td><td id="15d" class="so"><?php echo"$zy15d <br> $zyzy15d <br> $zyzyzy15d";?></td></tr>
    <tr><td id="16d" class="si"><?php echo"$zy16d <br> $zyzy16d <br> $zyzyzy16d";?></td><td id="17d" class="se"><?php echo"$zy17d <br> $zyzy17d <br> $zyzyzy17d";?></td><td id="18d" class="se"><?php echo"$zy18d <br> $zyzy18d <br> $zyzyzy18d";?></td><td id="19d" class="se"><?php echo"$zy19d <br> $zyzy19d <br> $zyzyzy19d";?></td><td id="20d" class="se"><?php echo"$zy20d <br> $zyzy20d <br> $zyzyzy20d";?></td><td id="21d" class="se"><?php echo"$zy21d <br> $zyzy21d <br> $zyzyzy21d";?></td><td id="22d" class="so"><?php echo"$zy22d <br> $zyzy22d <br> $zyzyzy22d";?></td></tr>
    <tr><td id="23d" class="si"><?php echo"$zy23d <br> $zyzy23d <br> $zyzyzy23d";?></td><td id="24d" class="se"><?php echo"$zy24d <br> $zyzy24d <br> $zyzyzy24d";?></td><td id="25d" class="se"><?php echo"$zy25d <br> $zyzy25d <br> $zyzyzy25d";?></td><td id="26d" class="se"><?php echo"$zy26d <br> $zyzy26d <br> $zyzyzy26d";?></td><td id="27d" class="se"><?php echo"$zy27d <br> $zyzy27d <br> $zyzyzy27d";?></td><td id="28d" class="se"><?php echo"$zy28d <br> $zyzy28d <br> $zyzyzy28d";?></td><td id="29d" class="so"><?php echo"$zy29d <br> $zyzy29d <br> $zyzyzy29d";?></td></tr>
    <tr><td id="30d" class="si"><?php echo"$zy30d <br> $zyzy30d <br> $zyzyzy30d";?></td><td id="31d" class="se"><?php echo"$zy31d <br> $zyzy31d <br> $zyzyzy31d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="agosto.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>