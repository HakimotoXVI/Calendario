<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("zf1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf1",$maccabeus1);
  }
}
$zf1d=isset($_COOKIE["zf1"])?$_COOKIE["zf1"]:1;
$zfzf1d=isset($_COOKIE["zfzf1"])?$_COOKIE["zfzf1"]:"";
$zfzfzf1d=isset($_COOKIE["zfzfzf1"])?$_COOKIE["zfzfzf1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("zf2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf2",$maccabeus1);
  }
}
$zf2d=isset($_COOKIE["zf2"])?$_COOKIE["zf2"]:2;
$zfzf2d=isset($_COOKIE["zfzf2"])?$_COOKIE["zfzf2"]:"";
$zfzfzf2d=isset($_COOKIE["zfzfzf2"])?$_COOKIE["zfzfzf2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("zf3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf3",$maccabeus1);
    $zfzf1d=isset($_COOKIE["zfzf3"])?$_COOKIE["zfzf3"]:"";
  }
  if($taf=="3"){
    setcookie("zfzfzf3",$maccabeus1);
  }
}
$zf3d=isset($_COOKIE["zf3"])?$_COOKIE["zf3"]:3;
$zfzf3d=isset($_COOKIE["zfzf3"])?$_COOKIE["zfzf3"]:"";
$zfzfzf3d=isset($_COOKIE["zfzfzf3"])?$_COOKIE["zfzfzf3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("zf4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf4",$maccabeus1);
  }
}
$zf4d=isset($_COOKIE["zf4"])?$_COOKIE["zf4"]:4;
$zfzf4d=isset($_COOKIE["zfzf4"])?$_COOKIE["zfzf4"]:"";
$zfzfzf4d=isset($_COOKIE["zfzfzf4"])?$_COOKIE["zfzfzf4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("zf5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf5",$maccabeus1);
  }
}
$zf5d=isset($_COOKIE["zf5"])?$_COOKIE["zf5"]:5;
$zfzf5d=isset($_COOKIE["zfzf5"])?$_COOKIE["zfzf5"]:"";
$zfzfzf5d=isset($_COOKIE["zfzfzf5"])?$_COOKIE["zfzfzf5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("zf6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf6",$maccabeus1);
  }
}
$zf6d=isset($_COOKIE["zf6"])?$_COOKIE["zf6"]:6;
$zfzf6d=isset($_COOKIE["zfzf6"])?$_COOKIE["zfzf6"]:"";
$zfzfzf6d=isset($_COOKIE["zfzfzf6"])?$_COOKIE["zfzfzf6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("zf7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf7",$maccabeus1);
  }
}
$zf7d=isset($_COOKIE["zf7"])?$_COOKIE["zf7"]:7;
$zfzf7d=isset($_COOKIE["zfzf7"])?$_COOKIE["zfzf7"]:"";
$zfzfzf7d=isset($_COOKIE["zfzfzf7"])?$_COOKIE["zfzfzf7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("zf8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf8",$maccabeus1);
  }
}
$zf8d=isset($_COOKIE["zf8"])?$_COOKIE["zf8"]:8;
$zfzf8d=isset($_COOKIE["zfzf8"])?$_COOKIE["zfzf8"]:"";
$zfzfzf8d=isset($_COOKIE["zfzfzf8"])?$_COOKIE["zfzfzf8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("zf9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf9",$maccabeus1);
  }
}
$zf9d=isset($_COOKIE["zf9"])?$_COOKIE["zf9"]:9;
$zfzf9d=isset($_COOKIE["zfzf9"])?$_COOKIE["zfzf9"]:"";
$zfzfzf9d=isset($_COOKIE["zfzfzf9"])?$_COOKIE["zfzfzf9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("zf10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf10",$maccabeus1);
  }
}
$zf10d=isset($_COOKIE["zf10"])?$_COOKIE["zf10"]:10;
$zfzf10d=isset($_COOKIE["zfzf10"])?$_COOKIE["zfzf10"]:"";
$zfzfzf10d=isset($_COOKIE["zfzfzf10"])?$_COOKIE["zfzfzf10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("zf11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf11",$maccabeus1);
  }
}
$zf11d=isset($_COOKIE["zf11"])?$_COOKIE["zf11"]:11;
$zfzf11d=isset($_COOKIE["zfzf11"])?$_COOKIE["zfzf11"]:"";
$zfzfzf11d=isset($_COOKIE["zfzfzf11"])?$_COOKIE["zfzfzf11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("zf12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf12",$maccabeus1);
  }
}
$zf12d=isset($_COOKIE["zf12"])?$_COOKIE["zf12"]:12;
$zfzf12d=isset($_COOKIE["zfzf12"])?$_COOKIE["zfzf12"]:"";
$zfzfzf12d=isset($_COOKIE["zfzfzf12"])?$_COOKIE["zfzfzf12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("zf13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf13",$maccabeus1);
  }
}
$zf13d=isset($_COOKIE["zf13"])?$_COOKIE["zf13"]:13;
$zfzf13d=isset($_COOKIE["zfzf13"])?$_COOKIE["zfzf13"]:"";
$zfzfzf13d=isset($_COOKIE["zfzfzf13"])?$_COOKIE["zfzfzf13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("zf14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf14",$maccabeus1);
  }
}
$zf14d=isset($_COOKIE["zf14"])?$_COOKIE["zf14"]:14;
$zfzf14d=isset($_COOKIE["zfzf14"])?$_COOKIE["zfzf14"]:"";
$zfzfzf14d=isset($_COOKIE["zfzfzf14"])?$_COOKIE["zfzfzf14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("zf15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf15",$maccabeus1);
  }
}
$zf15d=isset($_COOKIE["zf15"])?$_COOKIE["zf1"]:15;
$zfzf15d=isset($_COOKIE["zfzf15"])?$_COOKIE["zfzf15"]:"";
$zfzfzf15d=isset($_COOKIE["zfzfzf15"])?$_COOKIE["zfzfzf15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("zf16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf16",$maccabeus1);
  }
}
$zf16d=isset($_COOKIE["zf16"])?$_COOKIE["zf16"]:16;
$zfzf16d=isset($_COOKIE["zfzf16"])?$_COOKIE["zfzf16"]:"";
$zfzfzf16d=isset($_COOKIE["zfzfzf16"])?$_COOKIE["zfzfzf16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("zf17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf17",$maccabeus1);
  }
}
$zf17d=isset($_COOKIE["zf17"])?$_COOKIE["zf17"]:17;
$zfzf17d=isset($_COOKIE["zfzf17"])?$_COOKIE["zfzf17"]:"";
$zfzfzf17d=isset($_COOKIE["zfzfzf17"])?$_COOKIE["zfzfzf17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("zf18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf18",$maccabeus1);
  }
}
$zf18d=isset($_COOKIE["zf18"])?$_COOKIE["zf18"]:18;
$zfzf18d=isset($_COOKIE["zfzf18"])?$_COOKIE["zfzf18"]:"";
$zfzfzf18d=isset($_COOKIE["zfzfzf18"])?$_COOKIE["zfzfzf18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("zf19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf19",$maccabeus1);
  }
}
$zf19d=isset($_COOKIE["zf19"])?$_COOKIE["zf19"]:19;
$zfzf19d=isset($_COOKIE["zfzf19"])?$_COOKIE["zfzf19"]:"";
$zfzfzf19d=isset($_COOKIE["zfzfzf19"])?$_COOKIE["zfzfzf19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("zf2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf2",$maccabeus1);
  }
}
$zf20d=isset($_COOKIE["zf2"])?$_COOKIE["zf2"]:20;
$zfzf20d=isset($_COOKIE["zfzf2"])?$_COOKIE["zfzf2"]:"";
$zfzfzf20d=isset($_COOKIE["zfzfzf2"])?$_COOKIE["zfzfzf2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("zf21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf21",$maccabeus1);
  }
}
$zf21d=isset($_COOKIE["zf21"])?$_COOKIE["zf21"]:21;
$zfzf21d=isset($_COOKIE["zfzf21"])?$_COOKIE["zfzf21"]:"";
$zfzfzf21d=isset($_COOKIE["zfzfzf21"])?$_COOKIE["zfzfzf21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("zf22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf22",$maccabeus1);
  }
}
$zf22d=isset($_COOKIE["zf22"])?$_COOKIE["zf22"]:22;
$zfzf22d=isset($_COOKIE["zfzf22"])?$_COOKIE["zfzf22"]:"";
$zfzfzf22d=isset($_COOKIE["zfzfzf22"])?$_COOKIE["zfzfzf22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("zf23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf23",$maccabeus1);
  }
}
$zf23d=isset($_COOKIE["zf23"])?$_COOKIE["zf23"]:23;
$zfzf23d=isset($_COOKIE["zfzf23"])?$_COOKIE["zfzf23"]:"";
$zfzfzf23d=isset($_COOKIE["zfzfzf23"])?$_COOKIE["zfzfzf23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("zf24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf24",$maccabeus1);
  }
}
$zf24d=isset($_COOKIE["zf24"])?$_COOKIE["zf24"]:24;
$zfzf24d=isset($_COOKIE["zfzf24"])?$_COOKIE["zfzf24"]:"";
$zfzfzf24d=isset($_COOKIE["zfzfzf24"])?$_COOKIE["zfzfzf24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("zf25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf25",$maccabeus1);
  }
}
$zf25d=isset($_COOKIE["zf25"])?$_COOKIE["zf25"]:25;
$zfzf25d=isset($_COOKIE["zfzf25"])?$_COOKIE["zfzf25"]:"";
$zfzfzf25d=isset($_COOKIE["zfzfzf25"])?$_COOKIE["zfzfzf25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("zf26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf26",$maccabeus1);
  }
}
$zf26d=isset($_COOKIE["zf26"])?$_COOKIE["zf26"]:26;
$zfzf26d=isset($_COOKIE["zfzf26"])?$_COOKIE["zfzf26"]:"";
$zfzfzf26d=isset($_COOKIE["zfzfzf26"])?$_COOKIE["zfzfzf26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("zf27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf27",$maccabeus1);
  }
}
$zf27d=isset($_COOKIE["zf27"])?$_COOKIE["zf27"]:27;
$zfzf27d=isset($_COOKIE["zfzf27"])?$_COOKIE["zfzf27"]:"";
$zfzfzf27d=isset($_COOKIE["zfzfzf27"])?$_COOKIE["zfzfzf27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("zf28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf28",$maccabeus1);
  }
}
$zf28d=isset($_COOKIE["zf28"])?$_COOKIE["zf28"]:28;
$zfzf28d=isset($_COOKIE["zfzf28"])?$_COOKIE["zfzf28"]:"";
$zfzfzf28d=isset($_COOKIE["zfzfzf28"])?$_COOKIE["zfzfzf28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("zf29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zfzf29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zfzfzf29",$maccabeus1);
  }
}
$zf29d=isset($_COOKIE["zf29"])?$_COOKIE["zf29"]:29;
$zfzf29d=isset($_COOKIE["zfzf29"])?$_COOKIE["zfzf29"]:"";
$zfzfzf29d=isset($_COOKIE["zfzfzf29"])?$_COOKIE["zfzfzf29"]:"";
// if($dia=="30"){//30
//   if($taf=="1"){
//     setcookie("zf30",$maccabeus1);
//   }
//   if($taf=="2"){
//     setcookie("zfzf30",$maccabeus1);
//   }
//   if($taf=="3"){
//     setcookie("zfzfzf30",$maccabeus1);
//   }
// }
// $zf30d=isset($_COOKIE["zf30"])?$_COOKIE["zf30"]:30;
// $zfzf30d=isset($_COOKIE["zfzf30"])?$_COOKIE["zfzf30"]:"";
// $zfzfzf30d=isset($_COOKIE["zfzfzf30"])?$_COOKIE["zfzfzf30"]:"";
// if($dia=="31"){//31
//   if($taf=="1"){
//     setcookie("zf31",$maccabeus1);
//   }
//   if($taf=="2"){
//     setcookie("zfzf31",$maccabeus1);
//   }
//   if($taf=="3"){
//     setcookie("zfzfzf31",$maccabeus1);
//   }
// }
// $zf31d=isset($_COOKIE["zf31"])?$_COOKIE["zf31"]:31;
// $zfzf31d=isset($_COOKIE["zfzf31"])?$_COOKIE["zfzf31"]:"";
// $zfzfzf31d=isset($_COOKIE["zfzfzf31"])?$_COOKIE["zfzfzf31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Fevereiro</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Fevereiro</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Fevereiro</p>
<p class="yoda">Olá, seja bem vindo ao caléndario, aqui se encontra as tarefas do més de Fevereiro.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td class="si"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td id="1d" class="so"><?php echo"$zf1d <br> $zfzf1d <br> $zfzfzf1d";?></td></tr>
    <tr><td id="2d" class="si"><?php echo"$zf2d <br> $zfzf2d <br> $zfzfzf2d";?></td><td id="3d" class="se"><?php echo"$zf3d <br> $zfzf3d <br> $zfzfzf3d";?></td><td id="4d" class="se"><?php echo"$zf4d <br> $zfzf4d <br> $zfzfzf4d";?></td><td id="5d" class="se"><?php echo"$zf5d <br> $zfzf5d <br> $zfzfzf5d";?></td><td id="6d" class="se"><?php echo"$zf6d <br> $zfzf6d <br> $zfzfzf6d";?></td><td id="7d" class="se"><?php echo"$zf7d <br> $zfzf7d <br> $zfzfzf7d";?></td><td id="8d" class="so"><?php echo"$zf8d <br> $zfzf8d <br> $zfzfzf8d";?></td></tr>
    <tr><td id="9d" class="si"><?php echo"$zf9d <br> $zfzf9d <br> $zfzfzf9d";?></td><td id="10d" class="se"><?php echo"$zf10d <br> $zfzf10d <br> $zfzfzf10d";?></td><td id="11d" class="se"><?php echo"$zf11d <br> $zfzf11d <br> $zfzfzf11d";?></td><td id="12d" class="se"><?php echo"$zf12d <br> $zfzf12d <br> $zfzfzf12d";?></td><td id="13d" class="se"><?php echo"$zf13d <br> $zfzf13d <br> $zfzfzf13d";?></td><td id="14d" class="se"><?php echo"$zf14d <br> $zfzf14d <br> $zfzfzf14d";?></td><td id="15d" class="so"><?php echo"$zf15d <br> $zfzf15d <br> $zfzfzf15d";?></td></tr>
    <tr><td id="16d" class="si"><?php echo"$zf16d <br> $zfzf16d <br> $zfzfzf16d";?></td><td id="17d" class="se"><?php echo"$zf17d <br> $zfzf17d <br> $zfzfzf17d";?></td><td id="18d" class="se"><?php echo"$zf18d <br> $zfzf18d <br> $zfzfzf18d";?></td><td id="19d" class="se"><?php echo"$zf19d <br> $zfzf19d <br> $zfzfzf19d";?></td><td id="20d" class="se"><?php echo"$zf20d <br> $zfzf20d <br> $zfzfzf20d";?></td><td id="21d" class="se"><?php echo"$zf21d <br> $zfzf21d <br> $zfzfzf21d";?></td><td id="22d" class="so"><?php echo"$zf22d <br> $zfzf22d <br> $zfzfzf22d";?></td></tr>
    <tr><td id="23d" class="si"><?php echo"$zf23d <br> $zfzf23d <br> $zfzfzf23d";?></td><td id="24d" class="se"><?php echo"$zf24d <br> $zfzf24d <br> $zfzfzf24d";?></td><td id="25d" class="se"><?php echo"$zf25d <br> $zfzf25d <br> $zfzfzf25d";?></td><td id="26d" class="se"><?php echo"$zf26d <br> $zfzf26d <br> $zfzfzf26d";?></td><td id="27d" class="se"><?php echo"$zf27d <br> $zfzf27d <br> $zfzfzf27d";?></td><td id="28d" class="se"><?php echo"$zf28d <br> $zfzf28d <br> $zfzfzf28d";?></td><td id="29d" class="so"><?php echo"$zf29d <br> $zfzf29d <br> $zfzfzf29d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="fevereiro.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <!-- <option value="30">30</option>
        <option value="31">31</option> -->
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>