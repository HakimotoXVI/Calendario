<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("ll1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll1",$maccabeus1);
  }
}
$ll1d=isset($_COOKIE["ll1"])?$_COOKIE["ll1"]:1;
$llll1d=isset($_COOKIE["llll1"])?$_COOKIE["llll1"]:"";
$llllll1d=isset($_COOKIE["llllll1"])?$_COOKIE["llllll1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("ll2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll2",$maccabeus1);
  }
}
$ll2d=isset($_COOKIE["ll2"])?$_COOKIE["ll2"]:2;
$llll2d=isset($_COOKIE["llll2"])?$_COOKIE["llll2"]:"";
$llllll2d=isset($_COOKIE["llllll2"])?$_COOKIE["llllll2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("ll3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll3",$maccabeus1);
    $llll1d=isset($_COOKIE["llll3"])?$_COOKIE["llll3"]:"";
  }
  if($taf=="3"){
    setcookie("llllll3",$maccabeus1);
  }
}
$ll3d=isset($_COOKIE["ll3"])?$_COOKIE["ll3"]:3;
$llll3d=isset($_COOKIE["llll3"])?$_COOKIE["llll3"]:"";
$llllll3d=isset($_COOKIE["llllll3"])?$_COOKIE["llllll3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("ll4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll4",$maccabeus1);
  }
}
$ll4d=isset($_COOKIE["ll4"])?$_COOKIE["ll4"]:4;
$llll4d=isset($_COOKIE["llll4"])?$_COOKIE["llll4"]:"";
$llllll4d=isset($_COOKIE["llllll4"])?$_COOKIE["llllll4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("ll5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll5",$maccabeus1);
  }
}
$ll5d=isset($_COOKIE["ll5"])?$_COOKIE["ll5"]:5;
$llll5d=isset($_COOKIE["llll5"])?$_COOKIE["llll5"]:"";
$llllll5d=isset($_COOKIE["llllll5"])?$_COOKIE["llllll5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("ll6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll6",$maccabeus1);
  }
}
$ll6d=isset($_COOKIE["ll6"])?$_COOKIE["ll6"]:6;
$llll6d=isset($_COOKIE["llll6"])?$_COOKIE["llll6"]:"";
$llllll6d=isset($_COOKIE["llllll6"])?$_COOKIE["llllll6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("ll7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll7",$maccabeus1);
  }
}
$ll7d=isset($_COOKIE["ll7"])?$_COOKIE["ll7"]:7;
$llll7d=isset($_COOKIE["llll7"])?$_COOKIE["llll7"]:"";
$llllll7d=isset($_COOKIE["llllll7"])?$_COOKIE["llllll7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("ll8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll8",$maccabeus1);
  }
}
$ll8d=isset($_COOKIE["ll8"])?$_COOKIE["ll8"]:8;
$llll8d=isset($_COOKIE["llll8"])?$_COOKIE["llll8"]:"";
$llllll8d=isset($_COOKIE["llllll8"])?$_COOKIE["llllll8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("ll9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll9",$maccabeus1);
  }
}
$ll9d=isset($_COOKIE["ll9"])?$_COOKIE["ll9"]:9;
$llll9d=isset($_COOKIE["llll9"])?$_COOKIE["llll9"]:"";
$llllll9d=isset($_COOKIE["llllll9"])?$_COOKIE["llllll9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("ll10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll10",$maccabeus1);
  }
}
$ll10d=isset($_COOKIE["ll10"])?$_COOKIE["ll10"]:10;
$llll10d=isset($_COOKIE["llll10"])?$_COOKIE["llll10"]:"";
$llllll10d=isset($_COOKIE["llllll10"])?$_COOKIE["llllll10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("ll11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll11",$maccabeus1);
  }
}
$ll11d=isset($_COOKIE["ll11"])?$_COOKIE["ll11"]:11;
$llll11d=isset($_COOKIE["llll11"])?$_COOKIE["llll11"]:"";
$llllll11d=isset($_COOKIE["llllll11"])?$_COOKIE["llllll11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("ll12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll12",$maccabeus1);
  }
}
$ll12d=isset($_COOKIE["ll12"])?$_COOKIE["ll12"]:12;
$llll12d=isset($_COOKIE["llll12"])?$_COOKIE["llll12"]:"";
$llllll12d=isset($_COOKIE["llllll12"])?$_COOKIE["llllll12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("ll13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll13",$maccabeus1);
  }
}
$ll13d=isset($_COOKIE["ll13"])?$_COOKIE["ll13"]:13;
$llll13d=isset($_COOKIE["llll13"])?$_COOKIE["llll13"]:"";
$llllll13d=isset($_COOKIE["llllll13"])?$_COOKIE["llllll13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("ll14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll14",$maccabeus1);
  }
}
$ll14d=isset($_COOKIE["ll14"])?$_COOKIE["ll14"]:14;
$llll14d=isset($_COOKIE["llll14"])?$_COOKIE["llll14"]:"";
$llllll14d=isset($_COOKIE["llllll14"])?$_COOKIE["llllll14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("ll15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll15",$maccabeus1);
  }
}
$ll15d=isset($_COOKIE["ll15"])?$_COOKIE["ll1"]:15;
$llll15d=isset($_COOKIE["llll15"])?$_COOKIE["llll15"]:"";
$llllll15d=isset($_COOKIE["llllll15"])?$_COOKIE["llllll15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("ll16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll16",$maccabeus1);
  }
}
$ll16d=isset($_COOKIE["ll16"])?$_COOKIE["ll16"]:16;
$llll16d=isset($_COOKIE["llll16"])?$_COOKIE["llll16"]:"";
$llllll16d=isset($_COOKIE["llllll16"])?$_COOKIE["llllll16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("ll17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll17",$maccabeus1);
  }
}
$ll17d=isset($_COOKIE["ll17"])?$_COOKIE["ll17"]:17;
$llll17d=isset($_COOKIE["llll17"])?$_COOKIE["llll17"]:"";
$llllll17d=isset($_COOKIE["llllll17"])?$_COOKIE["llllll17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("ll18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll18",$maccabeus1);
  }
}
$ll18d=isset($_COOKIE["ll18"])?$_COOKIE["ll18"]:18;
$llll18d=isset($_COOKIE["llll18"])?$_COOKIE["llll18"]:"";
$llllll18d=isset($_COOKIE["llllll18"])?$_COOKIE["llllll18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("ll19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll19",$maccabeus1);
  }
}
$ll19d=isset($_COOKIE["ll19"])?$_COOKIE["ll19"]:19;
$llll19d=isset($_COOKIE["llll19"])?$_COOKIE["llll19"]:"";
$llllll19d=isset($_COOKIE["llllll19"])?$_COOKIE["llllll19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("ll2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll2",$maccabeus1);
  }
}
$ll20d=isset($_COOKIE["ll2"])?$_COOKIE["ll2"]:20;
$llll20d=isset($_COOKIE["llll2"])?$_COOKIE["llll2"]:"";
$llllll20d=isset($_COOKIE["llllll2"])?$_COOKIE["llllll2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("ll21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll21",$maccabeus1);
  }
}
$ll21d=isset($_COOKIE["ll21"])?$_COOKIE["ll21"]:21;
$llll21d=isset($_COOKIE["llll21"])?$_COOKIE["llll21"]:"";
$llllll21d=isset($_COOKIE["llllll21"])?$_COOKIE["llllll21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("ll22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll22",$maccabeus1);
  }
}
$ll22d=isset($_COOKIE["ll22"])?$_COOKIE["ll22"]:22;
$llll22d=isset($_COOKIE["llll22"])?$_COOKIE["llll22"]:"";
$llllll22d=isset($_COOKIE["llllll22"])?$_COOKIE["llllll22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("ll23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll23",$maccabeus1);
  }
}
$ll23d=isset($_COOKIE["ll23"])?$_COOKIE["ll23"]:23;
$llll23d=isset($_COOKIE["llll23"])?$_COOKIE["llll23"]:"";
$llllll23d=isset($_COOKIE["llllll23"])?$_COOKIE["llllll23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("ll24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll24",$maccabeus1);
  }
}
$ll24d=isset($_COOKIE["ll24"])?$_COOKIE["ll24"]:24;
$llll24d=isset($_COOKIE["llll24"])?$_COOKIE["llll24"]:"";
$llllll24d=isset($_COOKIE["llllll24"])?$_COOKIE["llllll24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("ll25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll25",$maccabeus1);
  }
}
$ll25d=isset($_COOKIE["ll25"])?$_COOKIE["ll25"]:25;
$llll25d=isset($_COOKIE["llll25"])?$_COOKIE["llll25"]:"";
$llllll25d=isset($_COOKIE["llllll25"])?$_COOKIE["llllll25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("ll26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll26",$maccabeus1);
  }
}
$ll26d=isset($_COOKIE["ll26"])?$_COOKIE["ll26"]:26;
$llll26d=isset($_COOKIE["llll26"])?$_COOKIE["llll26"]:"";
$llllll26d=isset($_COOKIE["llllll26"])?$_COOKIE["llllll26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("ll27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll27",$maccabeus1);
  }
}
$ll27d=isset($_COOKIE["ll27"])?$_COOKIE["ll27"]:27;
$llll27d=isset($_COOKIE["llll27"])?$_COOKIE["llll27"]:"";
$llllll27d=isset($_COOKIE["llllll27"])?$_COOKIE["llllll27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("ll28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll28",$maccabeus1);
  }
}
$ll28d=isset($_COOKIE["ll28"])?$_COOKIE["ll28"]:28;
$llll28d=isset($_COOKIE["llll28"])?$_COOKIE["llll28"]:"";
$llllll28d=isset($_COOKIE["llllll28"])?$_COOKIE["llllll28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("ll29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll29",$maccabeus1);
  }
}
$ll29d=isset($_COOKIE["ll29"])?$_COOKIE["ll29"]:29;
$llll29d=isset($_COOKIE["llll29"])?$_COOKIE["llll29"]:"";
$llllll29d=isset($_COOKIE["llllll29"])?$_COOKIE["llllll29"]:"";
if($dia=="30"){//30
  if($taf=="1"){
    setcookie("ll30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll30",$maccabeus1);
  }
}
$ll30d=isset($_COOKIE["ll30"])?$_COOKIE["ll30"]:30;
$llll30d=isset($_COOKIE["llll30"])?$_COOKIE["llll30"]:"";
$llllll30d=isset($_COOKIE["llllll30"])?$_COOKIE["llllll30"]:"";
if($dia=="31"){//31
  if($taf=="1"){
    setcookie("ll31",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("llll31",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("llllll31",$maccabeus1);
  }
}
$ll31d=isset($_COOKIE["ll31"])?$_COOKIE["ll31"]:31;
$llll31d=isset($_COOKIE["llll31"])?$_COOKIE["llll31"]:"";
$llllll31d=isset($_COOKIE["llllll31"])?$_COOKIE["llllll31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Outubro</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Outubro</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Outubro</p>
<p class="yoda">Olá, sella bem vindo ao caléndario, aqui se encontra as tarefas do més de Outubro.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td class="si"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td class="se"><?php echo"";?></td><td id="1d" class="se"><?php echo"$ll1d <br> $llll1d <br> $llllll1d";?></td><td id="2d" class="se"><?php echo"$ll2d <br> $llll2d <br> $llllll2d";?></td><td id="3d" class="so"><?php echo"$ll3d <br> $llll3d <br> $llllll3d";?></td></tr>
    <tr><td id="4d" class="si"><?php echo"$ll4d <br> $llll4d <br> $llllll4d";?></td><td id="5d" class="se"><?php echo"$ll5d <br> $llll5d <br> $llllll5d";?></td><td id="6d" class="se"><?php echo"$ll6d <br> $llll6d <br> $llllll6d";?></td><td id="7d" class="se"><?php echo"$ll7d <br> $llll7d <br> $llllll7d";?></td><td id="8d" class="se"><?php echo"$ll8d <br> $llll8d <br> $llllll8d";?></td><td id="9d" class="se"><?php echo"$ll9d <br> $llll9d <br> $llllll9d";?></td><td id="10d" class="so"><?php echo"$ll10d <br> $llll10d <br> $llllll10d";?></td></tr>
    <tr><td id="11d" class="si"><?php echo"$ll11d <br> $llll11d <br> $llllll11d";?></td><td id="12d" class="se"><?php echo"$ll12d <br> $llll12d <br> $llllll12d";?></td><td id="13d" class="se"><?php echo"$ll13d <br> $llll13d <br> $llllll13d";?></td><td id="14d" class="se"><?php echo"$ll14d <br> $llll14d <br> $llllll14d";?></td><td id="15d" class="se"><?php echo"$ll15d <br> $llll15d <br> $llllll15d";?></td><td id="16d" class="se"><?php echo"$ll16d <br> $llll16d <br> $llllll16d";?></td><td id="17d" class="so"><?php echo"$ll17d <br> $llll17d <br> $llllll17d";?></td></tr>
    <tr><td id="18d" class="si"><?php echo"$ll18d <br> $llll18d <br> $llllll18d";?></td><td id="19d" class="se"><?php echo"$ll19d <br> $llll19d <br> $llllll19d";?></td><td id="20d" class="se"><?php echo"$ll20d <br> $llll20d <br> $llllll20d";?></td><td id="21d" class="se"><?php echo"$ll21d <br> $llll21d <br> $llllll21d";?></td><td id="22d" class="se"><?php echo"$ll22d <br> $llll22d <br> $llllll22d";?></td><td id="23d" class="se"><?php echo"$ll23d <br> $llll23d <br> $llllll23d";?></td><td id="24d" class="so"><?php echo"$ll24d <br> $llll24d <br> $llllll24d";?></td></tr>
    <tr><td id="25d" class="si"><?php echo"$ll25d <br> $llll25d <br> $llllll25d";?></td><td id="26d" class="se"><?php echo"$ll26d <br> $llll26d <br> $llllll26d";?></td><td id="27d" class="se"><?php echo"$ll27d <br> $llll27d <br> $llllll27d";?></td><td id="28d" class="se"><?php echo"$ll28d <br> $llll28d <br> $llllll28d";?></td><td id="29d" class="se"><?php echo"$ll29d <br> $llll29d <br> $llllll29d";?></td><td id="30d" class="se"><?php echo"$ll30d <br> $llll30d <br> $llllll30d";?></td><td id="31d" class="so"><?php echo"$ll31d <br> $llll31d <br> $llllll31d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="outubro.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>