<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="j1"){//dia 1
  if($taf=="1"){
    setcookie("j1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj1",$maccabeus1);
  }
}
$j1d=isset($_COOKIE["j1"])?$_COOKIE["j1"]:1;
$jj1d=isset($_COOKIE["jj1"])?$_COOKIE["jj1"]:"";
$jjj1d=isset($_COOKIE["jjj1"])?$_COOKIE["jjj1"]:"";
if($dia=="j2"){//2
  if($taf=="1"){
    setcookie("j2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj2",$maccabeus1);
  }
}
$j2d=isset($_COOKIE["j2"])?$_COOKIE["j2"]:2;
$jj2d=isset($_COOKIE["jj2"])?$_COOKIE["jj2"]:"";
$jjj2d=isset($_COOKIE["jjj2"])?$_COOKIE["jjj2"]:"";
if($dia=="j3"){//3
  if($taf=="1"){
    setcookie("j3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj3",$maccabeus1);
    $jj1d=isset($_COOKIE["jj3"])?$_COOKIE["jj3"]:"";
  }
  if($taf=="3"){
    setcookie("jjj3",$maccabeus1);
  }
}
$j3d=isset($_COOKIE["j3"])?$_COOKIE["j3"]:3;
$jj3d=isset($_COOKIE["jj3"])?$_COOKIE["jj3"]:"";
$jjj3d=isset($_COOKIE["jjj3"])?$_COOKIE["jjj3"]:"";
if($dia=="j4"){//4
  if($taf=="1"){
    setcookie("j4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj4",$maccabeus1);
  }
}
$j4d=isset($_COOKIE["j4"])?$_COOKIE["j4"]:4;
$jj4d=isset($_COOKIE["jj4"])?$_COOKIE["jj4"]:"";
$jjj4d=isset($_COOKIE["jjj4"])?$_COOKIE["jjj4"]:"";
if($dia=="j5"){//5
  if($taf=="1"){
    setcookie("j5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj5",$maccabeus1);
  }
}
$j5d=isset($_COOKIE["j5"])?$_COOKIE["j5"]:5;
$jj5d=isset($_COOKIE["jj5"])?$_COOKIE["jj5"]:"";
$jjj5d=isset($_COOKIE["jjj5"])?$_COOKIE["jjj5"]:"";
if($dia=="j6"){//6
  if($taf=="1"){
    setcookie("j6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj6",$maccabeus1);
  }
}
$j6d=isset($_COOKIE["j6"])?$_COOKIE["j6"]:6;
$jj6d=isset($_COOKIE["jj6"])?$_COOKIE["jj6"]:"";
$jjj6d=isset($_COOKIE["jjj6"])?$_COOKIE["jjj6"]:"";
if($dia=="j7"){//7
  if($taf=="1"){
    setcookie("j7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj7",$maccabeus1);
  }
}
$j7d=isset($_COOKIE["j7"])?$_COOKIE["j7"]:7;
$jj7d=isset($_COOKIE["jj7"])?$_COOKIE["jj7"]:"";
$jjj7d=isset($_COOKIE["jjj7"])?$_COOKIE["jjj7"]:"";
if($dia=="j8"){//8
  if($taf=="1"){
    setcookie("j8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj8",$maccabeus1);
  }
}
$j8d=isset($_COOKIE["j8"])?$_COOKIE["j8"]:8;
$jj8d=isset($_COOKIE["jj8"])?$_COOKIE["jj8"]:"";
$jjj8d=isset($_COOKIE["jjj8"])?$_COOKIE["jjj8"]:"";
if($dia=="j9"){//9
  if($taf=="1"){
    setcookie("j9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj9",$maccabeus1);
  }
}
$j9d=isset($_COOKIE["j9"])?$_COOKIE["j9"]:9;
$jj9d=isset($_COOKIE["jj9"])?$_COOKIE["jj9"]:"";
$jjj9d=isset($_COOKIE["jjj9"])?$_COOKIE["jjj9"]:"";
if($dia=="j10"){//10
  if($taf=="1"){
    setcookie("j10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj10",$maccabeus1);
  }
}
$j10d=isset($_COOKIE["j10"])?$_COOKIE["j10"]:10;
$jj10d=isset($_COOKIE["jj10"])?$_COOKIE["jj10"]:"";
$jjj10d=isset($_COOKIE["jjj10"])?$_COOKIE["jjj10"]:"";
if($dia=="j11"){//11
  if($taf=="1"){
    setcookie("j11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj11",$maccabeus1);
  }
}
$j11d=isset($_COOKIE["j11"])?$_COOKIE["j11"]:11;
$jj11d=isset($_COOKIE["jj11"])?$_COOKIE["jj11"]:"";
$jjj11d=isset($_COOKIE["jjj11"])?$_COOKIE["jjj11"]:"";
if($dia=="j12"){//12
  if($taf=="1"){
    setcookie("j12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj12",$maccabeus1);
  }
}
$j12d=isset($_COOKIE["j12"])?$_COOKIE["j12"]:12;
$jj12d=isset($_COOKIE["jj12"])?$_COOKIE["jj12"]:"";
$jjj12d=isset($_COOKIE["jjj12"])?$_COOKIE["jjj12"]:"";
if($dia=="j13"){//13
  if($taf=="1"){
    setcookie("j13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj13",$maccabeus1);
  }
}
$j13d=isset($_COOKIE["j13"])?$_COOKIE["j13"]:13;
$jj13d=isset($_COOKIE["jj13"])?$_COOKIE["jj13"]:"";
$jjj13d=isset($_COOKIE["jjj13"])?$_COOKIE["jjj13"]:"";
if($dia=="j14"){//14
  if($taf=="1"){
    setcookie("j14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj14",$maccabeus1);
  }
}
$j14d=isset($_COOKIE["j14"])?$_COOKIE["j14"]:14;
$jj14d=isset($_COOKIE["jj14"])?$_COOKIE["jj14"]:"";
$jjj14d=isset($_COOKIE["jjj14"])?$_COOKIE["jjj14"]:"";
if($dia=="j15"){//15
  if($taf=="1"){
    setcookie("j15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj15",$maccabeus1);
  }
}
$j15d=isset($_COOKIE["j15"])?$_COOKIE["j1"]:15;
$jj15d=isset($_COOKIE["jj15"])?$_COOKIE["jj15"]:"";
$jjj15d=isset($_COOKIE["jjj15"])?$_COOKIE["jjj15"]:"";
if($dia=="j16"){//16
  if($taf=="1"){
    setcookie("j16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj16",$maccabeus1);
  }
}
$j16d=isset($_COOKIE["j16"])?$_COOKIE["j16"]:16;
$jj16d=isset($_COOKIE["jj16"])?$_COOKIE["jj16"]:"";
$jjj16d=isset($_COOKIE["jjj16"])?$_COOKIE["jjj16"]:"";
if($dia=="j17"){//17
  if($taf=="1"){
    setcookie("j17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj17",$maccabeus1);
  }
}
$j17d=isset($_COOKIE["j17"])?$_COOKIE["j17"]:17;
$jj17d=isset($_COOKIE["jj17"])?$_COOKIE["jj17"]:"";
$jjj17d=isset($_COOKIE["jjj17"])?$_COOKIE["jjj17"]:"";
if($dia=="j18"){//18
  if($taf=="1"){
    setcookie("j18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj18",$maccabeus1);
  }
}
$j18d=isset($_COOKIE["j18"])?$_COOKIE["j18"]:18;
$jj18d=isset($_COOKIE["jj18"])?$_COOKIE["jj18"]:"";
$jjj18d=isset($_COOKIE["jjj18"])?$_COOKIE["jjj18"]:"";
if($dia=="j19"){//19
  if($taf=="1"){
    setcookie("j19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj19",$maccabeus1);
  }
}
$j19d=isset($_COOKIE["j19"])?$_COOKIE["j19"]:19;
$jj19d=isset($_COOKIE["jj19"])?$_COOKIE["jj19"]:"";
$jjj19d=isset($_COOKIE["jjj19"])?$_COOKIE["jjj19"]:"";
if($dia=="j20"){//20
  if($taf=="1"){
    setcookie("j2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj2",$maccabeus1);
  }
}
$j20d=isset($_COOKIE["j2"])?$_COOKIE["j2"]:20;
$jj20d=isset($_COOKIE["jj2"])?$_COOKIE["jj2"]:"";
$jjj20d=isset($_COOKIE["jjj2"])?$_COOKIE["jjj2"]:"";
if($dia=="j21"){//21
  if($taf=="1"){
    setcookie("j21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj21",$maccabeus1);
  }
}
$j21d=isset($_COOKIE["j21"])?$_COOKIE["j21"]:21;
$jj21d=isset($_COOKIE["jj21"])?$_COOKIE["jj21"]:"";
$jjj21d=isset($_COOKIE["jjj21"])?$_COOKIE["jjj21"]:"";
if($dia=="j22"){//22
  if($taf=="1"){
    setcookie("j22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj22",$maccabeus1);
  }
}
$j22d=isset($_COOKIE["j22"])?$_COOKIE["j22"]:22;
$jj22d=isset($_COOKIE["jj22"])?$_COOKIE["jj22"]:"";
$jjj22d=isset($_COOKIE["jjj22"])?$_COOKIE["jjj22"]:"";
if($dia=="j23"){//23
  if($taf=="1"){
    setcookie("j23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj23",$maccabeus1);
  }
}
$j23d=isset($_COOKIE["j23"])?$_COOKIE["j23"]:23;
$jj23d=isset($_COOKIE["jj23"])?$_COOKIE["jj23"]:"";
$jjj23d=isset($_COOKIE["jjj23"])?$_COOKIE["jjj23"]:"";
if($dia=="j24"){//24
  if($taf=="1"){
    setcookie("j24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj24",$maccabeus1);
  }
}
$j24d=isset($_COOKIE["j24"])?$_COOKIE["j24"]:24;
$jj24d=isset($_COOKIE["jj24"])?$_COOKIE["jj24"]:"";
$jjj24d=isset($_COOKIE["jjj24"])?$_COOKIE["jjj24"]:"";
if($dia=="j25"){//25
  if($taf=="1"){
    setcookie("j25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj25",$maccabeus1);
  }
}
$j25d=isset($_COOKIE["j25"])?$_COOKIE["j25"]:25;
$jj25d=isset($_COOKIE["jj25"])?$_COOKIE["jj25"]:"";
$jjj25d=isset($_COOKIE["jjj25"])?$_COOKIE["jjj25"]:"";
if($dia=="j26"){//26
  if($taf=="1"){
    setcookie("j26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj26",$maccabeus1);
  }
}
$j26d=isset($_COOKIE["j26"])?$_COOKIE["j26"]:26;
$jj26d=isset($_COOKIE["jj26"])?$_COOKIE["jj26"]:"";
$jjj26d=isset($_COOKIE["jjj26"])?$_COOKIE["jjj26"]:"";
if($dia=="j27"){//27
  if($taf=="1"){
    setcookie("j27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj27",$maccabeus1);
  }
}
$j27d=isset($_COOKIE["j27"])?$_COOKIE["j27"]:27;
$jj27d=isset($_COOKIE["jj27"])?$_COOKIE["jj27"]:"";
$jjj27d=isset($_COOKIE["jjj27"])?$_COOKIE["jjj27"]:"";
if($dia=="j28"){//28
  if($taf=="1"){
    setcookie("j28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj28",$maccabeus1);
  }
}
$j28d=isset($_COOKIE["j28"])?$_COOKIE["j28"]:28;
$jj28d=isset($_COOKIE["jj28"])?$_COOKIE["jj28"]:"";
$jjj28d=isset($_COOKIE["jjj28"])?$_COOKIE["jjj28"]:"";
if($dia=="j29"){//29
  if($taf=="1"){
    setcookie("j29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj29",$maccabeus1);
  }
}
$j29d=isset($_COOKIE["j29"])?$_COOKIE["j29"]:29;
$jj29d=isset($_COOKIE["jj29"])?$_COOKIE["jj29"]:"";
$jjj29d=isset($_COOKIE["jjj29"])?$_COOKIE["jjj29"]:"";
if($dia=="j30"){//30
  if($taf=="1"){
    setcookie("j30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj30",$maccabeus1);
  }
}
$j30d=isset($_COOKIE["j30"])?$_COOKIE["j30"]:30;
$jj30d=isset($_COOKIE["jj30"])?$_COOKIE["jj30"]:"";
$jjj30d=isset($_COOKIE["jjj30"])?$_COOKIE["jjj30"]:"";
if($dia=="j31"){//31
  if($taf=="1"){
    setcookie("j31",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("jj31",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jjj31",$maccabeus1);
  }
}
$j31d=isset($_COOKIE["j31"])?$_COOKIE["j31"]:31;
$jj31d=isset($_COOKIE["jj31"])?$_COOKIE["jj31"]:"";
$jjj31d=isset($_COOKIE["jjj31"])?$_COOKIE["jjj31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Janeiro</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Janeiro</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Janeiro</p>
<p class="yoda">Olá, seja bem vindo ao caléndario, aqui se encontra as tarefas do més de Janeiro.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td id="33d" class="si"><?php echo"";?></td><td id="32d" class="se"><?php echo"";?></td><td id="33d" class="se"><?php echo"";?></td><td id="1d" class="se"><?php echo"$j1d <br> $jj1d <br> $jjj1d";?></td><td id="2d" class="se"><?php echo"$j2d <br> $jj2d <br> $jjj2d";?></td><td id="3d" class="se"><?php echo"$j3d <br> $jj3d <br> $jjj3d";?></td><td id="4d" class="so"><?php echo"$j4d <br> $jj4d <br> $jjj4d";?></td></tr>
    <tr><td id="5d" class="si"><?php echo"$j5d <br> $jj5d <br> $jjj5d";?></td><td id="6d" class="se"><?php echo"$j6d <br> $jj6d <br> $jjj6d";?></td><td id="7d" class="se"><?php echo"$j7d <br> $jj7d <br> $jjj7d";?></td><td id="8d" class="se"><?php echo"$j8d <br> $jj8d <br> $jjj8d";?></td><td id="9d" class="se"><?php echo"$j9d <br> $jj9d <br> $jjj9d";?></td><td id="10d" class="se"><?php echo"$j10d <br> $jj10d <br> $jjj10d";?></td><td id="11d" class="so"><?php echo"$j11d <br> $jj11d <br> $jjj11d";?></td></tr>
    <tr><td id="12d" class="si"><?php echo"$j12d <br> $jj12d <br> $jjj12d";?></td><td id="13d" class="se"><?php echo"$j13d <br> $jj13d <br> $jjj13d";?></td><td id="14d" class="se"><?php echo"$j14d <br> $jj14d <br> $jjj14d";?></td><td id="15d" class="se"><?php echo"$j15d <br> $jj15d <br> $jjj15d";?></td><td id="16d" class="se"><?php echo"$j16d <br> $jj16d <br> $jjj16d";?></td><td id="17d" class="se"><?php echo"$j17d <br> $jj17d <br> $jjj17d";?></td><td id="18d" class="so"><?php echo"$j18d <br> $jj18d <br> $jjj18d";?></td></tr>
    <tr><td id="19d" class="si"><?php echo"$j19d <br> $jj19d <br> $jjj19d";?></td><td id="20d" class="se"><?php echo"$j20d <br> $jj20d <br> $jjj20d";?></td><td id="21d" class="se"><?php echo"$j21d <br> $jj21d <br> $jjj21d";?></td><td id="22d" class="se"><?php echo"$j22d <br> $jj22d <br> $jjj22d";?></td><td id="23d" class="se"><?php echo"$j23d <br> $jj23d <br> $jjj23d";?></td><td id="24d" class="se"><?php echo"$j24d <br> $jj24d <br> $jjj24d";?></td><td id="25d" class="so"><?php echo"$j25d <br> $jj25d <br> $jjj25d";?></td></tr>
    <tr><td id="26d" class="si"><?php echo"$j26d <br> $jj26d <br> $jjj26d";?></td><td id="27d" class="se"><?php echo"$j27d <br> $jj27d <br> $jjj27d";?></td><td id="28d" class="se"><?php echo"$j28d <br> $jj28d <br> $jjj28d";?></td><td id="29d" class="se"><?php echo"$j29d <br> $jj29d <br> $jjj29d";?></td><td id="30d" class="se"><?php echo"$j30d <br> $jj30d <br> $jjj30d";?></td><td id="31d" class="se"><?php echo"$j31d <br> $jj31d <br> $jjj31d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="janeiro.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="j1">1</option>
        <option value="j2">2</option>
        <option value="j3">3</option>
        <option value="j4">4</option>
        <option value="j5">5</option>
        <option value="j6">6</option>
        <option value="j7">7</option>
        <option value="j8">8</option>
        <option value="j9">9</option>
        <option value="j10">10</option>
        <option value="j11">11</option>
        <option value="j12">12</option>
        <option value="j13">13</option>
        <option value="j14">14</option>
        <option value="j15">15</option>
        <option value="j16">16</option>
        <option value="j17">17</option>
        <option value="j18">18</option>
        <option value="j19">19</option>
        <option value="j20">20</option>
        <option value="j21">21</option>
        <option value="j22">22</option>
        <option value="j23">23</option>
        <option value="j24">24</option>
        <option value="j25">25</option>
        <option value="j26">26</option>
        <option value="j27">27</option>
        <option value="j28">28</option>
        <option value="j29">29</option>
        <option value="j30">30</option>
        <option value="j31">31</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>

<!--&copy;-->