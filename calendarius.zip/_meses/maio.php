<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("m1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm1",$maccabeus1);
  }
}
$m1d=isset($_COOKIE["m1"])?$_COOKIE["m1"]:1;
$mm1d=isset($_COOKIE["mm1"])?$_COOKIE["mm1"]:"";
$mmm1d=isset($_COOKIE["mmm1"])?$_COOKIE["mmm1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("m2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm2",$maccabeus1);
  }
}
$m2d=isset($_COOKIE["m2"])?$_COOKIE["m2"]:2;
$mm2d=isset($_COOKIE["mm2"])?$_COOKIE["mm2"]:"";
$mmm2d=isset($_COOKIE["mmm2"])?$_COOKIE["mmm2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("m3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm3",$maccabeus1);
    $mm1d=isset($_COOKIE["mm3"])?$_COOKIE["mm3"]:"";
  }
  if($taf=="3"){
    setcookie("mmm3",$maccabeus1);
  }
}
$m3d=isset($_COOKIE["m3"])?$_COOKIE["m3"]:3;
$mm3d=isset($_COOKIE["mm3"])?$_COOKIE["mm3"]:"";
$mmm3d=isset($_COOKIE["mmm3"])?$_COOKIE["mmm3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("m4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm4",$maccabeus1);
  }
}
$m4d=isset($_COOKIE["m4"])?$_COOKIE["m4"]:4;
$mm4d=isset($_COOKIE["mm4"])?$_COOKIE["mm4"]:"";
$mmm4d=isset($_COOKIE["mmm4"])?$_COOKIE["mmm4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("m5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm5",$maccabeus1);
  }
}
$m5d=isset($_COOKIE["m5"])?$_COOKIE["m5"]:5;
$mm5d=isset($_COOKIE["mm5"])?$_COOKIE["mm5"]:"";
$mmm5d=isset($_COOKIE["mmm5"])?$_COOKIE["mmm5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("m6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm6",$maccabeus1);
  }
}
$m6d=isset($_COOKIE["m6"])?$_COOKIE["m6"]:6;
$mm6d=isset($_COOKIE["mm6"])?$_COOKIE["mm6"]:"";
$mmm6d=isset($_COOKIE["mmm6"])?$_COOKIE["mmm6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("m7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm7",$maccabeus1);
  }
}
$m7d=isset($_COOKIE["m7"])?$_COOKIE["m7"]:7;
$mm7d=isset($_COOKIE["mm7"])?$_COOKIE["mm7"]:"";
$mmm7d=isset($_COOKIE["mmm7"])?$_COOKIE["mmm7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("m8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm8",$maccabeus1);
  }
}
$m8d=isset($_COOKIE["m8"])?$_COOKIE["m8"]:8;
$mm8d=isset($_COOKIE["mm8"])?$_COOKIE["mm8"]:"";
$mmm8d=isset($_COOKIE["mmm8"])?$_COOKIE["mmm8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("m9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm9",$maccabeus1);
  }
}
$m9d=isset($_COOKIE["m9"])?$_COOKIE["m9"]:9;
$mm9d=isset($_COOKIE["mm9"])?$_COOKIE["mm9"]:"";
$mmm9d=isset($_COOKIE["mmm9"])?$_COOKIE["mmm9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("m10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm10",$maccabeus1);
  }
}
$m10d=isset($_COOKIE["m10"])?$_COOKIE["m10"]:10;
$mm10d=isset($_COOKIE["mm10"])?$_COOKIE["mm10"]:"";
$mmm10d=isset($_COOKIE["mmm10"])?$_COOKIE["mmm10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("m11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm11",$maccabeus1);
  }
}
$m11d=isset($_COOKIE["m11"])?$_COOKIE["m11"]:11;
$mm11d=isset($_COOKIE["mm11"])?$_COOKIE["mm11"]:"";
$mmm11d=isset($_COOKIE["mmm11"])?$_COOKIE["mmm11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("m12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm12",$maccabeus1);
  }
}
$m12d=isset($_COOKIE["m12"])?$_COOKIE["m12"]:12;
$mm12d=isset($_COOKIE["mm12"])?$_COOKIE["mm12"]:"";
$mmm12d=isset($_COOKIE["mmm12"])?$_COOKIE["mmm12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("m13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm13",$maccabeus1);
  }
}
$m13d=isset($_COOKIE["m13"])?$_COOKIE["m13"]:13;
$mm13d=isset($_COOKIE["mm13"])?$_COOKIE["mm13"]:"";
$mmm13d=isset($_COOKIE["mmm13"])?$_COOKIE["mmm13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("m14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm14",$maccabeus1);
  }
}
$m14d=isset($_COOKIE["m14"])?$_COOKIE["m14"]:14;
$mm14d=isset($_COOKIE["mm14"])?$_COOKIE["mm14"]:"";
$mmm14d=isset($_COOKIE["mmm14"])?$_COOKIE["mmm14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("m15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm15",$maccabeus1);
  }
}
$m15d=isset($_COOKIE["m15"])?$_COOKIE["m1"]:15;
$mm15d=isset($_COOKIE["mm15"])?$_COOKIE["mm15"]:"";
$mmm15d=isset($_COOKIE["mmm15"])?$_COOKIE["mmm15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("m16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm16",$maccabeus1);
  }
}
$m16d=isset($_COOKIE["m16"])?$_COOKIE["m16"]:16;
$mm16d=isset($_COOKIE["mm16"])?$_COOKIE["mm16"]:"";
$mmm16d=isset($_COOKIE["mmm16"])?$_COOKIE["mmm16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("m17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm17",$maccabeus1);
  }
}
$m17d=isset($_COOKIE["m17"])?$_COOKIE["m17"]:17;
$mm17d=isset($_COOKIE["mm17"])?$_COOKIE["mm17"]:"";
$mmm17d=isset($_COOKIE["mmm17"])?$_COOKIE["mmm17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("m18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm18",$maccabeus1);
  }
}
$m18d=isset($_COOKIE["m18"])?$_COOKIE["m18"]:18;
$mm18d=isset($_COOKIE["mm18"])?$_COOKIE["mm18"]:"";
$mmm18d=isset($_COOKIE["mmm18"])?$_COOKIE["mmm18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("m19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm19",$maccabeus1);
  }
}
$m19d=isset($_COOKIE["m19"])?$_COOKIE["m19"]:19;
$mm19d=isset($_COOKIE["mm19"])?$_COOKIE["mm19"]:"";
$mmm19d=isset($_COOKIE["mmm19"])?$_COOKIE["mmm19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("m2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm2",$maccabeus1);
  }
}
$m20d=isset($_COOKIE["m2"])?$_COOKIE["m2"]:20;
$mm20d=isset($_COOKIE["mm2"])?$_COOKIE["mm2"]:"";
$mmm20d=isset($_COOKIE["mmm2"])?$_COOKIE["mmm2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("m21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm21",$maccabeus1);
  }
}
$m21d=isset($_COOKIE["m21"])?$_COOKIE["m21"]:21;
$mm21d=isset($_COOKIE["mm21"])?$_COOKIE["mm21"]:"";
$mmm21d=isset($_COOKIE["mmm21"])?$_COOKIE["mmm21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("m22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm22",$maccabeus1);
  }
}
$m22d=isset($_COOKIE["m22"])?$_COOKIE["m22"]:22;
$mm22d=isset($_COOKIE["mm22"])?$_COOKIE["mm22"]:"";
$mmm22d=isset($_COOKIE["mmm22"])?$_COOKIE["mmm22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("m23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm23",$maccabeus1);
  }
}
$m23d=isset($_COOKIE["m23"])?$_COOKIE["m23"]:23;
$mm23d=isset($_COOKIE["mm23"])?$_COOKIE["mm23"]:"";
$mmm23d=isset($_COOKIE["mmm23"])?$_COOKIE["mmm23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("m24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm24",$maccabeus1);
  }
}
$m24d=isset($_COOKIE["m24"])?$_COOKIE["m24"]:24;
$mm24d=isset($_COOKIE["mm24"])?$_COOKIE["mm24"]:"";
$mmm24d=isset($_COOKIE["mmm24"])?$_COOKIE["mmm24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("m25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm25",$maccabeus1);
  }
}
$m25d=isset($_COOKIE["m25"])?$_COOKIE["m25"]:25;
$mm25d=isset($_COOKIE["mm25"])?$_COOKIE["mm25"]:"";
$mmm25d=isset($_COOKIE["mmm25"])?$_COOKIE["mmm25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("m26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm26",$maccabeus1);
  }
}
$m26d=isset($_COOKIE["m26"])?$_COOKIE["m26"]:26;
$mm26d=isset($_COOKIE["mm26"])?$_COOKIE["mm26"]:"";
$mmm26d=isset($_COOKIE["mmm26"])?$_COOKIE["mmm26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("m27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm27",$maccabeus1);
  }
}
$m27d=isset($_COOKIE["m27"])?$_COOKIE["m27"]:27;
$mm27d=isset($_COOKIE["mm27"])?$_COOKIE["mm27"]:"";
$mmm27d=isset($_COOKIE["mmm27"])?$_COOKIE["mmm27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("m28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm28",$maccabeus1);
  }
}
$m28d=isset($_COOKIE["m28"])?$_COOKIE["m28"]:28;
$mm28d=isset($_COOKIE["mm28"])?$_COOKIE["mm28"]:"";
$mmm28d=isset($_COOKIE["mmm28"])?$_COOKIE["mmm28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("m29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm29",$maccabeus1);
  }
}
$m29d=isset($_COOKIE["m29"])?$_COOKIE["m29"]:29;
$mm29d=isset($_COOKIE["mm29"])?$_COOKIE["mm29"]:"";
$mmm29d=isset($_COOKIE["mmm29"])?$_COOKIE["mmm29"]:"";
if($dia=="30"){//30
  if($taf=="1"){
    setcookie("m30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm30",$maccabeus1);
  }
}
$m30d=isset($_COOKIE["m30"])?$_COOKIE["m30"]:30;
$mm30d=isset($_COOKIE["mm30"])?$_COOKIE["mm30"]:"";
$mmm30d=isset($_COOKIE["mmm30"])?$_COOKIE["mmm30"]:"";
if($dia=="31"){//31
  if($taf=="1"){
    setcookie("m31",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("mm31",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("mmm31",$maccabeus1);
  }
}
$m31d=isset($_COOKIE["m31"])?$_COOKIE["m31"]:31;
$mm31d=isset($_COOKIE["mm31"])?$_COOKIE["mm31"]:"";
$mmm31d=isset($_COOKIE["mmm31"])?$_COOKIE["mmm31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>maneiro</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Maio</h1>
<p>maccabeus</p><br>
<p>maccabeus</p><br>
<p>maccabeus</p><br>
<p>maccabeus</p><br>
<div id="corpo">
<p id="titulomes">Maio</p>
<p class="yoda">Olá, sema bem vindo ao caléndario, aqui se encontra as tarefas do més de Maio.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td id="1d" class="si"><?php echo"";?></td><td id="2d" class="se"><?php echo"";?></td><td id="3d" class="se"><?php echo"";?></td><td id="4d" class="se"><?php echo"";?></td><td id="5d" class="se"><?php echo"";?></td><td id="6d" class="se"><?php echo"$m1d <br> $mm1d <br> $mmm1d";?></td><td id="7d" class="so"><?php echo"$m2d <br> $mm2d <br> $mmm2d";?></td></tr>
    <tr><td id="8d" class="si"><?php echo"$m3d <br> $mm3d <br> $mmm3d";?></td><td id="9d" class="se"><?php echo"$m4d <br> $mm4d <br> $mmm4d";?></td><td id="10d" class="se"><?php echo"$m5d <br> $mm5d <br> $mmm5d";?></td><td id="11d" class="se"><?php echo"$m6d <br> $mm6d <br> $mmm6d";?></td><td id="12d" class="se"><?php echo"$m7d <br> $mm7d <br> $mmm7d";?></td><td id="13d" class="se"><?php echo"$m8d <br> $mm8d <br> $mmm8d";?></td><td id="14d" class="so"><?php echo"$m9d <br> $mm9d <br> $mmm9d";?></td></tr>
    <tr><td id="15d" class="si"><?php echo"$m10d <br> $mm10d <br> $mmm10d";?></td><td id="16d" class="se"><?php echo"$m11d <br> $mm11d <br> $mmm11d";?></td><td id="17d" class="se"><?php echo"$m12d <br> $mm12d <br> $mmm12d";?></td><td id="18d" class="se"><?php echo"$m13d <br> $mm13d <br> $mmm13d";?></td><td id="19d" class="se"><?php echo"$m14d <br> $mm14d <br> $mmm14d";?></td><td id="20d" class="se"><?php echo"$m15d <br> $mm15d <br> $mmm15d";?></td><td id="21d" class="so"><?php echo"$m16d <br> $mm16d <br> $mmm16d";?></td></tr>
    <tr><td id="22d" class="si"><?php echo"$m17d <br> $mm17d <br> $mmm17d";?></td><td id="23d" class="se"><?php echo"$m18d <br> $mm18d <br> $mmm18d";?></td><td id="24d" class="se"><?php echo"$m19d <br> $mm19d <br> $mmm19d";?></td><td id="25d" class="se"><?php echo"$m20d <br> $mm20d <br> $mmm20d";?></td><td id="26d" class="se"><?php echo"$m21d <br> $mm21d <br> $mmm21d";?></td><td id="27d" class="se"><?php echo"$m22d <br> $mm22d <br> $mmm22d";?></td><td id="28d" class="so"><?php echo"$m23d <br> $mm23d <br> $mmm23d";?></td></tr>
    <tr><td id="29d" class="si"><?php echo"$m24d <br> $mm24d <br> $mmm24d";?></td><td id="30d" class="se"><?php echo"$m25d <br> $mm25d <br> $mmm25d";?></td><td id="36d" class="se"><?php echo"$m27d <br> $mm27d <br> $mmm27d";?></td><td id="31d" class="se"><?php echo"$m26d <br> $mm26d <br> $mmm26d";?></td><td id="32d" class="se"><?php echo"$m28d <br> $mm28d <br> $mmm28d";?></td><td id="33d" class="se"><?php echo"$m29d <br> $mm29d <br> $mmm29d";?></td><td id="34d" class="so"><?php echo"$m30d <br> $mmm30d <br> $mmm30d";?></td></tr></tr>
    <tr><td id="35d" class="si"><?php echo"$m31d <br> $mm31d <br> $mmm31d";?></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="maio.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="31">31</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>