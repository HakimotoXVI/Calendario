<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("zd1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd1",$maccabeus1);
  }
}
$zd1d=isset($_COOKIE["zd1"])?$_COOKIE["zd1"]:1;
$zdzd1d=isset($_COOKIE["zdzd1"])?$_COOKIE["zdzd1"]:"";
$zdzdzd1d=isset($_COOKIE["zdzdzd1"])?$_COOKIE["zdzdzd1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("zd2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd2",$maccabeus1);
  }
}
$zd2d=isset($_COOKIE["zd2"])?$_COOKIE["zd2"]:2;
$zdzd2d=isset($_COOKIE["zdzd2"])?$_COOKIE["zdzd2"]:"";
$zdzdzd2d=isset($_COOKIE["zdzdzd2"])?$_COOKIE["zdzdzd2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("zd3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd3",$maccabeus1);
    $zdzd1d=isset($_COOKIE["zdzd3"])?$_COOKIE["zdzd3"]:"";
  }
  if($taf=="3"){
    setcookie("zdzdzd3",$maccabeus1);
  }
}
$zd3d=isset($_COOKIE["zd3"])?$_COOKIE["zd3"]:3;
$zdzd3d=isset($_COOKIE["zdzd3"])?$_COOKIE["zdzd3"]:"";
$zdzdzd3d=isset($_COOKIE["zdzdzd3"])?$_COOKIE["zdzdzd3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("zd4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd4",$maccabeus1);
  }
}
$zd4d=isset($_COOKIE["zd4"])?$_COOKIE["zd4"]:4;
$zdzd4d=isset($_COOKIE["zdzd4"])?$_COOKIE["zdzd4"]:"";
$zdzdzd4d=isset($_COOKIE["zdzdzd4"])?$_COOKIE["zdzdzd4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("zd5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd5",$maccabeus1);
  }
}
$zd5d=isset($_COOKIE["zd5"])?$_COOKIE["zd5"]:5;
$zdzd5d=isset($_COOKIE["zdzd5"])?$_COOKIE["zdzd5"]:"";
$zdzdzd5d=isset($_COOKIE["zdzdzd5"])?$_COOKIE["zdzdzd5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("zd6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd6",$maccabeus1);
  }
}
$zd6d=isset($_COOKIE["zd6"])?$_COOKIE["zd6"]:6;
$zdzd6d=isset($_COOKIE["zdzd6"])?$_COOKIE["zdzd6"]:"";
$zdzdzd6d=isset($_COOKIE["zdzdzd6"])?$_COOKIE["zdzdzd6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("zd7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd7",$maccabeus1);
  }
}
$zd7d=isset($_COOKIE["zd7"])?$_COOKIE["zd7"]:7;
$zdzd7d=isset($_COOKIE["zdzd7"])?$_COOKIE["zdzd7"]:"";
$zdzdzd7d=isset($_COOKIE["zdzdzd7"])?$_COOKIE["zdzdzd7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("zd8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd8",$maccabeus1);
  }
}
$zd8d=isset($_COOKIE["zd8"])?$_COOKIE["zd8"]:8;
$zdzd8d=isset($_COOKIE["zdzd8"])?$_COOKIE["zdzd8"]:"";
$zdzdzd8d=isset($_COOKIE["zdzdzd8"])?$_COOKIE["zdzdzd8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("zd9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd9",$maccabeus1);
  }
}
$zd9d=isset($_COOKIE["zd9"])?$_COOKIE["zd9"]:9;
$zdzd9d=isset($_COOKIE["zdzd9"])?$_COOKIE["zdzd9"]:"";
$zdzdzd9d=isset($_COOKIE["zdzdzd9"])?$_COOKIE["zdzdzd9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("zd10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd10",$maccabeus1);
  }
}
$zd10d=isset($_COOKIE["zd10"])?$_COOKIE["zd10"]:10;
$zdzd10d=isset($_COOKIE["zdzd10"])?$_COOKIE["zdzd10"]:"";
$zdzdzd10d=isset($_COOKIE["zdzdzd10"])?$_COOKIE["zdzdzd10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("zd11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd11",$maccabeus1);
  }
}
$zd11d=isset($_COOKIE["zd11"])?$_COOKIE["zd11"]:11;
$zdzd11d=isset($_COOKIE["zdzd11"])?$_COOKIE["zdzd11"]:"";
$zdzdzd11d=isset($_COOKIE["zdzdzd11"])?$_COOKIE["zdzdzd11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("zd12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd12",$maccabeus1);
  }
}
$zd12d=isset($_COOKIE["zd12"])?$_COOKIE["zd12"]:12;
$zdzd12d=isset($_COOKIE["zdzd12"])?$_COOKIE["zdzd12"]:"";
$zdzdzd12d=isset($_COOKIE["zdzdzd12"])?$_COOKIE["zdzdzd12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("zd13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd13",$maccabeus1);
  }
}
$zd13d=isset($_COOKIE["zd13"])?$_COOKIE["zd13"]:13;
$zdzd13d=isset($_COOKIE["zdzd13"])?$_COOKIE["zdzd13"]:"";
$zdzdzd13d=isset($_COOKIE["zdzdzd13"])?$_COOKIE["zdzdzd13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("zd14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd14",$maccabeus1);
  }
}
$zd14d=isset($_COOKIE["zd14"])?$_COOKIE["zd14"]:14;
$zdzd14d=isset($_COOKIE["zdzd14"])?$_COOKIE["zdzd14"]:"";
$zdzdzd14d=isset($_COOKIE["zdzdzd14"])?$_COOKIE["zdzdzd14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("zd15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd15",$maccabeus1);
  }
}
$zd15d=isset($_COOKIE["zd15"])?$_COOKIE["zd1"]:15;
$zdzd15d=isset($_COOKIE["zdzd15"])?$_COOKIE["zdzd15"]:"";
$zdzdzd15d=isset($_COOKIE["zdzdzd15"])?$_COOKIE["zdzdzd15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("zd16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd16",$maccabeus1);
  }
}
$zd16d=isset($_COOKIE["zd16"])?$_COOKIE["zd16"]:16;
$zdzd16d=isset($_COOKIE["zdzd16"])?$_COOKIE["zdzd16"]:"";
$zdzdzd16d=isset($_COOKIE["zdzdzd16"])?$_COOKIE["zdzdzd16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("zd17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd17",$maccabeus1);
  }
}
$zd17d=isset($_COOKIE["zd17"])?$_COOKIE["zd17"]:17;
$zdzd17d=isset($_COOKIE["zdzd17"])?$_COOKIE["zdzd17"]:"";
$zdzdzd17d=isset($_COOKIE["zdzdzd17"])?$_COOKIE["zdzdzd17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("zd18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd18",$maccabeus1);
  }
}
$zd18d=isset($_COOKIE["zd18"])?$_COOKIE["zd18"]:18;
$zdzd18d=isset($_COOKIE["zdzd18"])?$_COOKIE["zdzd18"]:"";
$zdzdzd18d=isset($_COOKIE["zdzdzd18"])?$_COOKIE["zdzdzd18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("zd19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd19",$maccabeus1);
  }
}
$zd19d=isset($_COOKIE["zd19"])?$_COOKIE["zd19"]:19;
$zdzd19d=isset($_COOKIE["zdzd19"])?$_COOKIE["zdzd19"]:"";
$zdzdzd19d=isset($_COOKIE["zdzdzd19"])?$_COOKIE["zdzdzd19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("zd2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd2",$maccabeus1);
  }
}
$zd20d=isset($_COOKIE["zd2"])?$_COOKIE["zd2"]:20;
$zdzd20d=isset($_COOKIE["zdzd2"])?$_COOKIE["zdzd2"]:"";
$zdzdzd20d=isset($_COOKIE["zdzdzd2"])?$_COOKIE["zdzdzd2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("zd21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd21",$maccabeus1);
  }
}
$zd21d=isset($_COOKIE["zd21"])?$_COOKIE["zd21"]:21;
$zdzd21d=isset($_COOKIE["zdzd21"])?$_COOKIE["zdzd21"]:"";
$zdzdzd21d=isset($_COOKIE["zdzdzd21"])?$_COOKIE["zdzdzd21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("zd22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd22",$maccabeus1);
  }
}
$zd22d=isset($_COOKIE["zd22"])?$_COOKIE["zd22"]:22;
$zdzd22d=isset($_COOKIE["zdzd22"])?$_COOKIE["zdzd22"]:"";
$zdzdzd22d=isset($_COOKIE["zdzdzd22"])?$_COOKIE["zdzdzd22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("zd23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd23",$maccabeus1);
  }
}
$zd23d=isset($_COOKIE["zd23"])?$_COOKIE["zd23"]:23;
$zdzd23d=isset($_COOKIE["zdzd23"])?$_COOKIE["zdzd23"]:"";
$zdzdzd23d=isset($_COOKIE["zdzdzd23"])?$_COOKIE["zdzdzd23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("zd24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd24",$maccabeus1);
  }
}
$zd24d=isset($_COOKIE["zd24"])?$_COOKIE["zd24"]:24;
$zdzd24d=isset($_COOKIE["zdzd24"])?$_COOKIE["zdzd24"]:"";
$zdzdzd24d=isset($_COOKIE["zdzdzd24"])?$_COOKIE["zdzdzd24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("zd25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd25",$maccabeus1);
  }
}
$zd25d=isset($_COOKIE["zd25"])?$_COOKIE["zd25"]:25;
$zdzd25d=isset($_COOKIE["zdzd25"])?$_COOKIE["zdzd25"]:"";
$zdzdzd25d=isset($_COOKIE["zdzdzd25"])?$_COOKIE["zdzdzd25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("zd26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd26",$maccabeus1);
  }
}
$zd26d=isset($_COOKIE["zd26"])?$_COOKIE["zd26"]:26;
$zdzd26d=isset($_COOKIE["zdzd26"])?$_COOKIE["zdzd26"]:"";
$zdzdzd26d=isset($_COOKIE["zdzdzd26"])?$_COOKIE["zdzdzd26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("zd27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd27",$maccabeus1);
  }
}
$zd27d=isset($_COOKIE["zd27"])?$_COOKIE["zd27"]:27;
$zdzd27d=isset($_COOKIE["zdzd27"])?$_COOKIE["zdzd27"]:"";
$zdzdzd27d=isset($_COOKIE["zdzdzd27"])?$_COOKIE["zdzdzd27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("zd28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd28",$maccabeus1);
  }
}
$zd28d=isset($_COOKIE["zd28"])?$_COOKIE["zd28"]:28;
$zdzd28d=isset($_COOKIE["zdzd28"])?$_COOKIE["zdzd28"]:"";
$zdzdzd28d=isset($_COOKIE["zdzdzd28"])?$_COOKIE["zdzdzd28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("zd29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd29",$maccabeus1);
  }
}
$zd29d=isset($_COOKIE["zd29"])?$_COOKIE["zd29"]:29;
$zdzd29d=isset($_COOKIE["zdzd29"])?$_COOKIE["zdzd29"]:"";
$zdzdzd29d=isset($_COOKIE["zdzdzd29"])?$_COOKIE["zdzdzd29"]:"";
if($dia=="30"){//30
  if($taf=="1"){
    setcookie("zd30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd30",$maccabeus1);
  }
}
$zd30d=isset($_COOKIE["zd30"])?$_COOKIE["zd30"]:30;
$zdzd30d=isset($_COOKIE["zdzd30"])?$_COOKIE["zdzd30"]:"";
$zdzdzd30d=isset($_COOKIE["zdzdzd30"])?$_COOKIE["zdzdzd30"]:"";
if($dia=="31"){//31
  if($taf=="1"){
    setcookie("zd31",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("zdzd31",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("zdzdzd31",$maccabeus1);
  }
}
$zd31d=isset($_COOKIE["zd31"])?$_COOKIE["zd31"]:31;
$zdzd31d=isset($_COOKIE["zdzd31"])?$_COOKIE["zdzd31"]:"";
$zdzdzd31d=isset($_COOKIE["zdzdzd31"])?$_COOKIE["zdzdzd31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Dezembro</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Dezembro</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Dezembro</p>
<p class="yoda">Olá, seja bem vindo ao caléndario, aqui se encontra as tarefas do més de Dezembro.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td id="1d" class="si"><?php echo"";?></td><td id="2d" class="se"><?php echo"";?></td><td id="1d" class="se"><?php echo"$zd1d <br> $zdzd1d <br> $zdzdzd1d";?></td><td id="2d" class="se"><?php echo"$zd2d <br> $zdzd2d <br> $zdzdzd2d";?></td><td id="3d" class="se"><?php echo"$zd3d <br> $zdzd3d <br> $zdzdzd3d";?></td><td id="4d" class="se"><?php echo"$zd4d <br> $zdzd4d <br> $zdzdzd4d";?></td><td id="5d" class="so"><?php echo"$zd5d <br> $zdzd5d <br> $zdzdzd5d";?></td></tr>
    <tr><td id="6d" class="si"><?php echo"$zd6d <br> $zdzd6d <br> $zdzdzd6d";?></td><td id="7d" class="se"><?php echo"$zd7d <br> $zdzd7d <br> $zdzdzd7d";?></td><td id="8d" class="se"><?php echo"$zd8d <br> $zdzd8d <br> $zdzdzd8d";?></td><td id="9d" class="se"><?php echo"$zd9d <br> $zdzd9d <br> $zdzdzd9d";?></td><td id="10d" class="se"><?php echo"$zd10d <br> $zdzd10d <br> $zdzdzd10d";?></td><td id="11d" class="se"><?php echo"$zd11d <br> $zdzd11d <br> $zdzdzd11d";?></td><td id="12d" class="so"><?php echo"$zd12d <br> $zdzd12d <br> $zdzdzd12d";?></td></tr>
    <tr><td id="13d" class="si"><?php echo"$zd13d <br> $zdzd13d <br> $zdzdzd13d";?></td><td id="14d" class="se"><?php echo"$zd14d <br> $zdzd14d <br> $zdzdzd14d";?></td><td id="15d" class="se"><?php echo"$zd15d <br> $zdzd15d <br> $zdzdzd15d";?></td><td id="16d" class="se"><?php echo"$zd16d <br> $zdzd16d <br> $zdzdzd16d";?></td><td id="17d" class="se"><?php echo"$zd17d <br> $zdzd17d <br> $zdzdzd17d";?></td><td id="18d" class="se"><?php echo"$zd18d <br> $zdzd18d <br> $zdzdzd18d";?></td><td id="19d" class="so"><?php echo"$zd19d <br> $zdzd19d <br> $zdzdzd19d";?></td></tr>
    <tr><td id="20d" class="si"><?php echo"$zd20d <br> $zdzd20d <br> $zdzdzd20d";?></td><td id="21d" class="se"><?php echo"$zd21d <br> $zdzd21d <br> $zdzdzd21d";?></td><td id="22d" class="se"><?php echo"$zd22d <br> $zdzd22d <br> $zdzdzd22d";?></td><td id="23d" class="se"><?php echo"$zd23d <br> $zdzd23d <br> $zdzdzd23d";?></td><td id="24d" class="se"><?php echo"$zd24d <br> $zdzd24d <br> $zdzdzd24d";?></td><td id="25d" class="se"><?php echo"$zd25d <br> $zdzd25d <br> $zdzdzd25d";?></td><td id="26d" class="so"><?php echo"$zd26d <br> $zdzd26d <br> $zdzdzd26d";?></td></tr>
    <tr><td id="27d" class="si"><?php echo"$zd27d <br> $zdzd27d <br> $zdzdzd27d";?></td><td id="28d" class="se"><?php echo"$zd28d <br> $zdzd28d <br> $zdzdzd28d";?></td><td id="29d" class="se"><?php echo"$zd29d <br> $zdzd29d <br> $zdzdzd29d";?></td><td id="30d" class="se"><?php echo"$zd30d <br> $zdzd30d <br> $zdzdzd30d";?></td><td id="31d" class="se"><?php echo"$zd31d <br> $zdzd31d <br> $zdzdzd31d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="janeiro.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="32">31</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>