<?php 
$textin = $_POST["txt"];
$mat= $_POST["cmat"];
$dia = $_POST["mdia"];
$maccabeus1="$mat:$textin";
$taf=$_POST["ttaf"];

if($dia=="1"){//dia 1
  if($taf=="1"){
    setcookie("ju1",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju1",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju1",$maccabeus1);
  }
}
$ju1d=isset($_COOKIE["ju1"])?$_COOKIE["ju1"]:1;
$juju1d=isset($_COOKIE["juju1"])?$_COOKIE["juju1"]:"";
$jujuju1d=isset($_COOKIE["jujuju1"])?$_COOKIE["jujuju1"]:"";
if($dia=="2"){//2
  if($taf=="1"){
    setcookie("ju2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju2",$maccabeus1);
  }
}
$ju2d=isset($_COOKIE["ju2"])?$_COOKIE["ju2"]:2;
$juju2d=isset($_COOKIE["juju2"])?$_COOKIE["juju2"]:"";
$jujuju2d=isset($_COOKIE["jujuju2"])?$_COOKIE["jujuju2"]:"";
if($dia=="3"){//3
  if($taf=="1"){
    setcookie("ju3",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju3",$maccabeus1);
    $juju1d=isset($_COOKIE["juju3"])?$_COOKIE["juju3"]:"";
  }
  if($taf=="3"){
    setcookie("jujuju3",$maccabeus1);
  }
}
$ju3d=isset($_COOKIE["ju3"])?$_COOKIE["ju3"]:3;
$juju3d=isset($_COOKIE["juju3"])?$_COOKIE["juju3"]:"";
$jujuju3d=isset($_COOKIE["jujuju3"])?$_COOKIE["jujuju3"]:"";
if($dia=="4"){//4
  if($taf=="1"){
    setcookie("ju4",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju4",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju4",$maccabeus1);
  }
}
$ju4d=isset($_COOKIE["ju4"])?$_COOKIE["ju4"]:4;
$juju4d=isset($_COOKIE["juju4"])?$_COOKIE["juju4"]:"";
$jujuju4d=isset($_COOKIE["jujuju4"])?$_COOKIE["jujuju4"]:"";
if($dia=="5"){//5
  if($taf=="1"){
    setcookie("ju5",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju5",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju5",$maccabeus1);
  }
}
$ju5d=isset($_COOKIE["ju5"])?$_COOKIE["ju5"]:5;
$juju5d=isset($_COOKIE["juju5"])?$_COOKIE["juju5"]:"";
$jujuju5d=isset($_COOKIE["jujuju5"])?$_COOKIE["jujuju5"]:"";
if($dia=="6"){//6
  if($taf=="1"){
    setcookie("ju6",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju6",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju6",$maccabeus1);
  }
}
$ju6d=isset($_COOKIE["ju6"])?$_COOKIE["ju6"]:6;
$juju6d=isset($_COOKIE["juju6"])?$_COOKIE["juju6"]:"";
$jujuju6d=isset($_COOKIE["jujuju6"])?$_COOKIE["jujuju6"]:"";
if($dia=="7"){//7
  if($taf=="1"){
    setcookie("ju7",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju7",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju7",$maccabeus1);
  }
}
$ju7d=isset($_COOKIE["ju7"])?$_COOKIE["ju7"]:7;
$juju7d=isset($_COOKIE["juju7"])?$_COOKIE["juju7"]:"";
$jujuju7d=isset($_COOKIE["jujuju7"])?$_COOKIE["jujuju7"]:"";
if($dia=="8"){//8
  if($taf=="1"){
    setcookie("ju8",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju8",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju8",$maccabeus1);
  }
}
$ju8d=isset($_COOKIE["ju8"])?$_COOKIE["ju8"]:8;
$juju8d=isset($_COOKIE["juju8"])?$_COOKIE["juju8"]:"";
$jujuju8d=isset($_COOKIE["jujuju8"])?$_COOKIE["jujuju8"]:"";
if($dia=="9"){//9
  if($taf=="1"){
    setcookie("ju9",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju9",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju9",$maccabeus1);
  }
}
$ju9d=isset($_COOKIE["ju9"])?$_COOKIE["ju9"]:9;
$juju9d=isset($_COOKIE["juju9"])?$_COOKIE["juju9"]:"";
$jujuju9d=isset($_COOKIE["jujuju9"])?$_COOKIE["jujuju9"]:"";
if($dia=="10"){//10
  if($taf=="1"){
    setcookie("ju10",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju10",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju10",$maccabeus1);
  }
}
$ju10d=isset($_COOKIE["ju10"])?$_COOKIE["ju10"]:10;
$juju10d=isset($_COOKIE["juju10"])?$_COOKIE["juju10"]:"";
$jujuju10d=isset($_COOKIE["jujuju10"])?$_COOKIE["jujuju10"]:"";
if($dia=="11"){//11
  if($taf=="1"){
    setcookie("ju11",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju11",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju11",$maccabeus1);
  }
}
$ju11d=isset($_COOKIE["ju11"])?$_COOKIE["ju11"]:11;
$juju11d=isset($_COOKIE["juju11"])?$_COOKIE["juju11"]:"";
$jujuju11d=isset($_COOKIE["jujuju11"])?$_COOKIE["jujuju11"]:"";
if($dia=="12"){//12
  if($taf=="1"){
    setcookie("ju12",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju12",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju12",$maccabeus1);
  }
}
$ju12d=isset($_COOKIE["ju12"])?$_COOKIE["ju12"]:12;
$juju12d=isset($_COOKIE["juju12"])?$_COOKIE["juju12"]:"";
$jujuju12d=isset($_COOKIE["jujuju12"])?$_COOKIE["jujuju12"]:"";
if($dia=="13"){//13
  if($taf=="1"){
    setcookie("ju13",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju13",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju13",$maccabeus1);
  }
}
$ju13d=isset($_COOKIE["ju13"])?$_COOKIE["ju13"]:13;
$juju13d=isset($_COOKIE["juju13"])?$_COOKIE["juju13"]:"";
$jujuju13d=isset($_COOKIE["jujuju13"])?$_COOKIE["jujuju13"]:"";
if($dia=="14"){//14
  if($taf=="1"){
    setcookie("ju14",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju14",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju14",$maccabeus1);
  }
}
$ju14d=isset($_COOKIE["ju14"])?$_COOKIE["ju14"]:14;
$juju14d=isset($_COOKIE["juju14"])?$_COOKIE["juju14"]:"";
$jujuju14d=isset($_COOKIE["jujuju14"])?$_COOKIE["jujuju14"]:"";
if($dia=="15"){//15
  if($taf=="1"){
    setcookie("ju15",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju15",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju15",$maccabeus1);
  }
}
$ju15d=isset($_COOKIE["ju15"])?$_COOKIE["ju1"]:15;
$juju15d=isset($_COOKIE["juju15"])?$_COOKIE["juju15"]:"";
$jujuju15d=isset($_COOKIE["jujuju15"])?$_COOKIE["jujuju15"]:"";
if($dia=="16"){//16
  if($taf=="1"){
    setcookie("ju16",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju16",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju16",$maccabeus1);
  }
}
$ju16d=isset($_COOKIE["ju16"])?$_COOKIE["ju16"]:16;
$juju16d=isset($_COOKIE["juju16"])?$_COOKIE["juju16"]:"";
$jujuju16d=isset($_COOKIE["jujuju16"])?$_COOKIE["jujuju16"]:"";
if($dia=="17"){//17
  if($taf=="1"){
    setcookie("ju17",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju17",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju17",$maccabeus1);
  }
}
$ju17d=isset($_COOKIE["ju17"])?$_COOKIE["ju17"]:17;
$juju17d=isset($_COOKIE["juju17"])?$_COOKIE["juju17"]:"";
$jujuju17d=isset($_COOKIE["jujuju17"])?$_COOKIE["jujuju17"]:"";
if($dia=="18"){//18
  if($taf=="1"){
    setcookie("ju18",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju18",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju18",$maccabeus1);
  }
}
$ju18d=isset($_COOKIE["ju18"])?$_COOKIE["ju18"]:18;
$juju18d=isset($_COOKIE["juju18"])?$_COOKIE["juju18"]:"";
$jujuju18d=isset($_COOKIE["jujuju18"])?$_COOKIE["jujuju18"]:"";
if($dia=="19"){//19
  if($taf=="1"){
    setcookie("ju19",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju19",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju19",$maccabeus1);
  }
}
$ju19d=isset($_COOKIE["ju19"])?$_COOKIE["ju19"]:19;
$juju19d=isset($_COOKIE["juju19"])?$_COOKIE["juju19"]:"";
$jujuju19d=isset($_COOKIE["jujuju19"])?$_COOKIE["jujuju19"]:"";
if($dia=="20"){//20
  if($taf=="1"){
    setcookie("ju2",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju2",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju2",$maccabeus1);
  }
}
$ju20d=isset($_COOKIE["ju2"])?$_COOKIE["ju2"]:20;
$juju20d=isset($_COOKIE["juju2"])?$_COOKIE["juju2"]:"";
$jujuju20d=isset($_COOKIE["jujuju2"])?$_COOKIE["jujuju2"]:"";
if($dia=="21"){//21
  if($taf=="1"){
    setcookie("ju21",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju21",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju21",$maccabeus1);
  }
}
$ju21d=isset($_COOKIE["ju21"])?$_COOKIE["ju21"]:21;
$juju21d=isset($_COOKIE["juju21"])?$_COOKIE["juju21"]:"";
$jujuju21d=isset($_COOKIE["jujuju21"])?$_COOKIE["jujuju21"]:"";
if($dia=="22"){//22
  if($taf=="1"){
    setcookie("ju22",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju22",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju22",$maccabeus1);
  }
}
$ju22d=isset($_COOKIE["ju22"])?$_COOKIE["ju22"]:22;
$juju22d=isset($_COOKIE["juju22"])?$_COOKIE["juju22"]:"";
$jujuju22d=isset($_COOKIE["jujuju22"])?$_COOKIE["jujuju22"]:"";
if($dia=="23"){//23
  if($taf=="1"){
    setcookie("ju23",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju23",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju23",$maccabeus1);
  }
}
$ju23d=isset($_COOKIE["ju23"])?$_COOKIE["ju23"]:23;
$juju23d=isset($_COOKIE["juju23"])?$_COOKIE["juju23"]:"";
$jujuju23d=isset($_COOKIE["jujuju23"])?$_COOKIE["jujuju23"]:"";
if($dia=="24"){//24
  if($taf=="1"){
    setcookie("ju24",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju24",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju24",$maccabeus1);
  }
}
$ju24d=isset($_COOKIE["ju24"])?$_COOKIE["ju24"]:24;
$juju24d=isset($_COOKIE["juju24"])?$_COOKIE["juju24"]:"";
$jujuju24d=isset($_COOKIE["jujuju24"])?$_COOKIE["jujuju24"]:"";
if($dia=="25"){//25
  if($taf=="1"){
    setcookie("ju25",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju25",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju25",$maccabeus1);
  }
}
$ju25d=isset($_COOKIE["ju25"])?$_COOKIE["ju25"]:25;
$juju25d=isset($_COOKIE["juju25"])?$_COOKIE["juju25"]:"";
$jujuju25d=isset($_COOKIE["jujuju25"])?$_COOKIE["jujuju25"]:"";
if($dia=="26"){//26
  if($taf=="1"){
    setcookie("ju26",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju26",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju26",$maccabeus1);
  }
}
$ju26d=isset($_COOKIE["ju26"])?$_COOKIE["ju26"]:26;
$juju26d=isset($_COOKIE["juju26"])?$_COOKIE["juju26"]:"";
$jujuju26d=isset($_COOKIE["jujuju26"])?$_COOKIE["jujuju26"]:"";
if($dia=="27"){//27
  if($taf=="1"){
    setcookie("ju27",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju27",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju27",$maccabeus1);
  }
}
$ju27d=isset($_COOKIE["ju27"])?$_COOKIE["ju27"]:27;
$juju27d=isset($_COOKIE["juju27"])?$_COOKIE["juju27"]:"";
$jujuju27d=isset($_COOKIE["jujuju27"])?$_COOKIE["jujuju27"]:"";
if($dia=="28"){//28
  if($taf=="1"){
    setcookie("ju28",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju28",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju28",$maccabeus1);
  }
}
$ju28d=isset($_COOKIE["ju28"])?$_COOKIE["ju28"]:28;
$juju28d=isset($_COOKIE["juju28"])?$_COOKIE["juju28"]:"";
$jujuju28d=isset($_COOKIE["jujuju28"])?$_COOKIE["jujuju28"]:"";
if($dia=="29"){//29
  if($taf=="1"){
    setcookie("ju29",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju29",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju29",$maccabeus1);
  }
}
$ju29d=isset($_COOKIE["ju29"])?$_COOKIE["ju29"]:29;
$juju29d=isset($_COOKIE["juju29"])?$_COOKIE["juju29"]:"";
$jujuju29d=isset($_COOKIE["jujuju29"])?$_COOKIE["jujuju29"]:"";
if($dia=="30"){//30
  if($taf=="1"){
    setcookie("ju30",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju30",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju30",$maccabeus1);
  }
}
$ju30d=isset($_COOKIE["ju30"])?$_COOKIE["ju30"]:30;
$juju30d=isset($_COOKIE["juju30"])?$_COOKIE["juju30"]:"";
$jujuju30d=isset($_COOKIE["jujuju30"])?$_COOKIE["jujuju30"]:"";
if($dia=="31"){//31
  if($taf=="1"){
    setcookie("ju31",$maccabeus1);
  }
  if($taf=="2"){
    setcookie("juju31",$maccabeus1);
  }
  if($taf=="3"){
    setcookie("jujuju31",$maccabeus1);
  }
}
$ju31d=isset($_COOKIE["ju31"])?$_COOKIE["ju31"]:31;
$juju31d=isset($_COOKIE["juju31"])?$_COOKIE["juju31"]:"";
$jujuju31d=isset($_COOKIE["jujuju31"])?$_COOKIE["jujuju31"]:"";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Junho</title>
    <link href="../commands.php">
    <link rel="stylesheet" href="../_css/_estilo.css"/>   
    <link rel="stylesheet" href="../_css/_calendario.css">
    <script src="../_js/commands.js"></script>
</head>
<body>
<header id="masc">
    <a id="logus" href="https://www.heineken.com/br/agegateway?returnurl=%2f" target="_blank">Maccabeus</a>
<nav id="maccabeus">
    <a href="janeiro.php">Janeiro</a>
    <a href="fevereiro.php">Fevereiro</a>
    <a href="marco.php">Março</a>
    <a href="abril.php">Abril</a>
    <a href="maio.php">Maio</a>
    <a href="junho.php">Junho</a>
    <a href="julho.php">Julho</a>
    <a href="agosto.php">Agosto</a>
    <a href="setembro.php">Setembro</a>
    <a href="outubro.php">Outubro</a>
    <a href="novembro.php">Novembro</a>
    <a href="dezembro.php">Dezembro</a>
</nav>
</header>
<h1 id="titulomes">Junho</h1>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<p>oba</p><br>
<div id="corpo">
<p id="titulomes">Junho</p>
<p class="yoda">Olá, seja bem vindo ao caléndario, aqui se encontra as tarefas do més de Junho.</p><br>
<p class="yoda">Se tiver alguma tarefa que não está colocada no calédario, por favor, adicione!</p><br>
<br><br>
<p id="workk">Tarefa</p>
<div id="aobis">
<table id="tabela">
    <tr><td class="sd">Domingo</td><td class="sd">Segunda</td><td class="sd">Terça</td><td class="sd">Quarta</td><td class="sd">Quinta</td><td class="sd">Sexta</td><td class="sd">Sábado</td></tr>
    <tr><td id="1d" class="si"><?php echo"";?></td><td id="1d" class="se"><?php echo"$ju1d <br> $juju1d <br> $jujuju1d";?></td><td id="2d" class="se"><?php echo"$ju2d <br> $juju2d <br> $jujuju2d";?></td><td id="3d" class="se"><?php echo"$ju3d <br> $juju3d <br> $jujuju3d";?></td><td id="4d" class="se"><?php echo"$ju4d <br> $juju4d <br> $jujuju4d";?></td><td id="5d" class="se"><?php echo"$ju5d <br> $juju5d <br> $jujuju5d";?></td><td id="6d" class="so"><?php echo"$ju6d <br> $juju6d <br> $jujuju6d";?></td></tr>
    <tr><td id="7d" class="si"><?php echo"$ju7d <br> $juju7d <br> $jujuju7d";?></td><td id="8d" class="se"><?php echo"$ju8d <br> $juju8d <br> $jujuju8d";?></td><td id="9d" class="se"><?php echo"$ju9d <br> $juju9d <br> $jujuju9d";?></td><td id="10d" class="se"><?php echo"$ju10d <br> $juju10d <br> $jujuju10d";?></td><td id="11d" class="se"><?php echo"$ju11d <br> $juju11d <br> $jujuju11d";?></td><td id="12d" class="se"><?php echo"$ju12d <br> $juju12d <br> $jujuju12d";?></td><td id="13d" class="so"><?php echo"$ju13d <br> $juju13d <br> $jujuju13d";?></td></tr>
    <tr><td id="14d" class="si"><?php echo"$ju14d <br> $juju14d <br> $jujuju14d";?></td><td id="15d" class="se"><?php echo"$ju15d <br> $juju15d <br> $jujuju15d";?></td><td id="16d" class="se"><?php echo"$ju16d <br> $juju16d <br> $jujuju16d";?></td><td id="17d" class="se"><?php echo"$ju17d <br> $juju17d <br> $jujuju17d";?></td><td id="18d" class="se"><?php echo"$ju18d <br> $juju18d <br> $jujuju18d";?></td><td id="19d" class="se"><?php echo"$ju19d <br> $juju19d <br> $jujuju19d";?></td><td id="20d" class="so"><?php echo"$ju20d <br> $juju20d <br> $jujuju20d";?></td></tr>
    <tr><td id="21d" class="si"><?php echo"$ju21d <br> $juju21d <br> $jujuju21d";?></td><td id="22d" class="se"><?php echo"$ju22d <br> $juju22d <br> $jujuju22d";?></td><td id="23d" class="se"><?php echo"$ju23d <br> $juju23d <br> $jujuju23d";?></td><td id="24d" class="se"><?php echo"$ju24d <br> $juju24d <br> $jujuju24d";?></td><td id="25d" class="se"><?php echo"$ju25d <br> $juju25d <br> $jujuju25d";?></td><td id="26d" class="se"><?php echo"$ju26d <br> $juju26d <br> $jujuju26d";?></td><td id="27d" class="so"><?php echo"$ju27d <br> $juju27d <br> $jujuju27d";?></td></tr>
    <tr><td id="28d" class="si"><?php echo"$ju28d <br> $juju28d <br> $jujuju28d";?></td><td id="29d" class="se"><?php echo"$ju29d <br> $juju29d <br> $jujuju29d";?></td><td id="30d" class="se"><?php echo"$ju30d <br> $juju30d <br> $jujuju30d";?></td></tr>
</table>
</div>
<br>
<br>
<br><br>
<p class="baxx">Para adicionar alguma tarefa, basta ir ao campo aqui abaixo.</p>
<p class="baxx">se não souber usar, recomendo que não tente.</p>
<p class="baxx">Mas caso houver alguma dúvida, é auto-explicativo.</p>
<br>
<br>
<br>
<br>
<div id="forms">
<form id="fform" name="fcad" method="POST" action="junho.php">
 <fieldset id="mat">
    <legend id="anot">Anotações da Tarefa</legend>
     <label class="color" for="cmat" id="cmat">Matéria:</label><br>
     <select name="cmat" id="cmat">
         <option value="Mat" id="mat">Matématica</option>
         <option value="Port" id="port">Português</option>
         <option value="Geo" id="geo" >Geografia</option>
         <option value="Esp" id="esp" >Espanhol</option>
         <option value="Bio" id="bio" >Biologia</option>
         <option value="Fis" id="fis" >Física</option>
         <option value="Qui" id="qui" >Quimica</option>
         <option value="His" id="his" >História</option>
         <option value="Fil" id="fil" >Filosofia</option>
         <option value="Soc" id="soc" >Sociologia</option>
         <option value="Ing" id="ing" >Ingles</option>
         <option value="DDW" id="ddw" >DDW</option>
         <option value="LPI" id="lpi" >LPI</option>
         <option value="Carl" id="carl" >Carlao</option>
     </select>

    <label class="color" for="mtfa"><br><br>Tarefa:</label>
    <input type="text" name="txt" id="txt" placeholder="Digite a tarefa:"> 

    <label class="color" for="mdia" id="mdia"><br><br>Dia:</label><br>
    <select name="mdia" id="mdia">
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
        <option value="13">13</option>
        <option value="14">14</option>
        <option value="15">15</option>
        <option value="16">16</option>
        <option value="17">17</option>
        <option value="18">18</option>
        <option value="19">19</option>
        <option value="20">20</option>
        <option value="21">21</option>
        <option value="22">22</option>
        <option value="23">23</option>
        <option value="24">24</option>
        <option value="25">25</option>
        <option value="26">26</option>
        <option value="27">27</option>
        <option value="28">28</option>
        <option value="29">29</option>
        <option value="30">30</option>
        <option value="32">31</option>
    </select>
    <label class="color" for="ttaf" id="ttaf"><br><br>Número:</label>
        <select name="ttaf" id="ttaf">
           <option value="1">1</option>
           <option value="2">2</option>
           <option value="3">3</option>
       </select><br>
   <br>
    <button class="butao" onclick="window.location.reload()">Send</button><br>
    <input type="reset" class="butao" value="Clear-Limpe">
</fieldset>
</select>
</form>
</div>
<p id="helps">Como usar?</p>
<p class="txhelp">Olá, no campo acima será escrito o conteúdo das tarefas, para, poteriormente, ser impresso no caléndario.</p><br>
<p class="txhelp">Primeiramente, coloque no campo: "Matéria", a matéria a qual pertence a tarefa que será colocada.</p>
<p class="txhelp">Logo em seguida, coloque no campo: "Tarefa", a tarefa de fato, como, págida, trabalho, etc.</p>
<p class="txhelp">Ja no campo "Dia", coloque o dia determinado para o recebimento da tarefa de fato.</p>
<p class="txhelp">Agora preste muita atenção! </p>
<p class="txhelp">Para não "bugar" o site, coloque no campo: "número", o número correspondente da tarefa no dia.</p>
<p class="txhelp">Por exemplo: se no dia teve 2 tarefas (Português, Matematica ), a primeira tarefa (Matématica) </p>
<p class="txhelp">com a caixa "Número:1" marcada, e a proxíma tarefa (Português) com a caixa "Número:2".</p>
<p class="txhelp">Tire bom proveito, ajuda aos coleguinhas</p>
</div>
<footer id="foot">
    <div id="mac">
    <p id="fot">By: Hakimoto &copy; </p>
    </div>
</footer>
</body>
</html>